// Tech Savvies ERP Support Call CRM - Authentication Routes
const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { getDb, logAudit } = require('../config/database');
const { isAuthenticated } = require('../middleware/auth');

// GET /auth/login
router.get('/login', (req, res) => {
  if (req.session && req.session.user) {
    return res.redirect(req.session.user.role === 'admin' ? '/admin/dashboard' : '/employee/dashboard');
  }
  res.render('auth/login', {
    pageTitle: 'Login'
  });
});

// POST /auth/login
router.post('/login', (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    req.flash('error', 'Please enter both username and password');
    return res.redirect('/auth/login');
  }

  try {
    const db = getDb();
    const user = db.prepare('SELECT * FROM users WHERE username = ? COLLATE NOCASE').get(username.trim());

    if (!user) {
      req.flash('error', 'Invalid username or password');
      return res.redirect('/auth/login');
    }

    const isMatch = bcrypt.compareSync(password, user.password);
    if (!isMatch) {
      req.flash('error', 'Invalid username or password');
      return res.redirect('/auth/login');
    }

    if (user.status !== 'approved') {
      const messages = {
        pending: 'Your account is pending admin approval. Please wait for an administrator to approve.',
        rejected: 'Your account registration was rejected. Please contact support.',
        blocked: 'Your account has been deactivated/blocked. Please contact support.'
      };
      req.flash('error', messages[user.status] || 'Your account is not approved to login.');
      return res.redirect('/auth/login');
    }

    // Set session user object
    req.session.user = {
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role,
      status: user.status
    };

    // Attach employee info if present
    const emp = db.prepare('SELECT id, emp_code, name, department, designation FROM employees WHERE user_id = ?').get(user.id);
    if (emp) {
      req.session.user.employee_id = emp.id;
      req.session.user.emp_code = emp.emp_code;
      req.session.user.name = emp.name;
      req.session.user.department = emp.department;
      req.session.user.designation = emp.designation;
    }

    logAudit(user.id, 'USER_LOGIN', `User ${user.username} logged in successfully`, req.ip);

    req.flash('success', 'Welcome back, ' + user.username + '!');

    if (user.role === 'admin') {
      return res.redirect('/admin/dashboard');
    } else {
      return res.redirect('/employee/dashboard');
    }
  } catch (err) {
    console.error('Login error:', err);
    req.flash('error', 'An error occurred during login. Please try again.');
    return res.redirect('/auth/login');
  }
});

// GET /auth/register
router.get('/register', (req, res) => {
  if (req.session && req.session.user) {
    return res.redirect(req.session.user.role === 'admin' ? '/admin/dashboard' : '/employee/dashboard');
  }
  res.render('auth/register', {
    pageTitle: 'Register'
  });
});

// POST /auth/register
router.post('/register', (req, res) => {
  const { username, email, password, confirm_password } = req.body;

  if (!username || !email || !password || !confirm_password) {
    req.flash('error', 'All fields are required');
    return res.redirect('/auth/register');
  }

  if (password !== confirm_password) {
    req.flash('error', 'Passwords do not match');
    return res.redirect('/auth/register');
  }

  if (password.length < 6) {
    req.flash('error', 'Password must be at least 6 characters long');
    return res.redirect('/auth/register');
  }

  try {
    const db = getDb();
    const existing = db.prepare('SELECT id FROM users WHERE username = ? COLLATE NOCASE OR email = ? COLLATE NOCASE').get(username.trim(), email.trim());

    if (existing) {
      req.flash('error', 'Username or email already in use');
      return res.redirect('/auth/register');
    }

    const hashedPassword = bcrypt.hashSync(password, 10);
    const result = db.prepare(`
      INSERT INTO users (username, email, password, role, status)
      VALUES (?, ?, ?, 'employee', 'pending')
    `).run(username.trim(), email.trim(), hashedPassword);

    logAudit(result.lastInsertRowid, 'USER_REGISTER', `New user registration for ${username} (Pending approval)`, req.ip);

    req.flash('success', 'Registration submitted successfully! Your account requires Administrator approval before you can log in.');
    return res.redirect('/auth/login');
  } catch (err) {
    console.error('Registration error:', err);
    req.flash('error', 'Registration failed: ' + err.message);
    return res.redirect('/auth/register');
  }
});

// GET /auth/logout
router.get('/logout', (req, res) => {
  if (req.session && req.session.user) {
    logAudit(req.session.user.id, 'USER_LOGOUT', `User ${req.session.user.username} logged out`, req.ip);
  }
  req.session.destroy(() => {
    res.redirect('/auth/login');
  });
});

// GET /auth/forgot-password
router.get('/forgot-password', (req, res) => {
  res.render('auth/forgot-password', {
    pageTitle: 'Forgot Password'
  });
});

// POST /auth/forgot-password
router.post('/forgot-password', (req, res) => {
  const { email } = req.body;

  if (!email) {
    req.flash('error', 'Please enter your registered email');
    return res.redirect('/auth/forgot-password');
  }

  try {
    const db = getDb();
    const user = db.prepare('SELECT id FROM users WHERE email = ? COLLATE NOCASE').get(email.trim());

    if (user) {
      const token = crypto.randomBytes(24).toString('hex');
      const expires = new Date(Date.now() + 3600000).toISOString(); // 1 hour

      db.prepare('UPDATE users SET reset_token = ?, reset_token_expires = ? WHERE id = ?')
        .run(token, expires, user.id);

      logAudit(user.id, 'PASSWORD_RESET_REQ', `Password reset token requested for email ${email}`, req.ip);

      req.flash('info', `Password reset token generated. In a production environment with SMTP configured, a link would be dispatched. You can reset directly at: /auth/reset-password/${token}`);
    } else {
      req.flash('info', 'If an account exists with that email, reset instructions have been generated.');
    }

    return res.redirect('/auth/login');
  } catch (err) {
    console.error('Forgot password error:', err);
    req.flash('error', 'An error occurred. Please try again.');
    return res.redirect('/auth/forgot-password');
  }
});

// GET /auth/reset-password/:token
router.get('/reset-password/:token', (req, res) => {
  const { token } = req.params;

  try {
    const db = getDb();
    const user = db.prepare(
      'SELECT * FROM users WHERE reset_token = ? AND reset_token_expires > ?'
    ).get(token, new Date().toISOString());

    if (!user) {
      req.flash('error', 'Invalid or expired reset token');
      return res.redirect('/auth/forgot-password');
    }

    res.render('auth/reset-password', {
      token,
      pageTitle: 'Reset Password'
    });
  } catch (err) {
    console.error('Reset password error:', err);
    req.flash('error', 'An error occurred. Please try again.');
    return res.redirect('/auth/forgot-password');
  }
});

// POST /auth/reset-password/:token
router.post('/reset-password/:token', (req, res) => {
  const { token } = req.params;
  const { password, confirm_password } = req.body;

  if (!password || !confirm_password) {
    req.flash('error', 'All fields are required');
    return res.redirect('/auth/reset-password/' + token);
  }

  if (password !== confirm_password) {
    req.flash('error', 'Passwords do not match');
    return res.redirect('/auth/reset-password/' + token);
  }

  if (password.length < 6) {
    req.flash('error', 'Password must be at least 6 characters long');
    return res.redirect('/auth/reset-password/' + token);
  }

  try {
    const db = getDb();
    const user = db.prepare(
      'SELECT * FROM users WHERE reset_token = ? AND reset_token_expires > ?'
    ).get(token, new Date().toISOString());

    if (!user) {
      req.flash('error', 'Invalid or expired reset token');
      return res.redirect('/auth/forgot-password');
    }

    const hashedPassword = bcrypt.hashSync(password, 10);

    db.prepare(
      'UPDATE users SET password = ?, reset_token = NULL, reset_token_expires = NULL, updated_at = CURRENT_TIMESTAMP WHERE id = ?'
    ).run(hashedPassword, user.id);

    logAudit(user.id, 'RESET_PASSWORD_SUCCESS', `Password successfully reset via token`, req.ip);

    req.flash('success', 'Password has been reset successfully. Please login.');
    return res.redirect('/auth/login');
  } catch (err) {
    console.error('Reset password error:', err);
    req.flash('error', 'An error occurred. Please try again.');
    return res.redirect('/auth/reset-password/' + token);
  }
});

// ═══════════════════════════════════════════════════
//  CHANGE CREDENTIALS (USERNAME & PASSWORD)
//  - ADMIN can change immediately
//  - USERS / EMPLOYEES submit request requiring ADMIN AUTHORIZATION
// ═══════════════════════════════════════════════════
router.get('/change-password', isAuthenticated, (req, res) => {
  const db = getDb();
  // Fetch existing pending change requests for current user
  const pendingRequest = db.prepare(`
    SELECT * FROM change_requests WHERE user_id = ? AND status = 'pending' ORDER BY id DESC LIMIT 1
  `).get(req.session.user.id);

  const requestHistory = db.prepare(`
    SELECT cr.*, u.username as reviewer_name
    FROM change_requests cr
    LEFT JOIN users u ON cr.reviewed_by = u.id
    WHERE cr.user_id = ?
    ORDER BY cr.created_at DESC LIMIT 5
  `).all(req.session.user.id);

  res.render('auth/change-password', {
    pageTitle: 'Change Credentials',
    user: req.session.user,
    pendingRequest,
    requestHistory
  });
});

router.post('/change-password', isAuthenticated, (req, res) => {
  const { current_password, new_username, new_password, confirm_password, reason } = req.body;
  const db = getDb();
  const currentUser = db.prepare('SELECT * FROM users WHERE id = ?').get(req.session.user.id);

  if (!currentUser) {
    req.flash('error', 'User not found');
    return res.redirect('/auth/login');
  }

  // Verify current password
  if (!current_password) {
    req.flash('error', 'Current password is required to request changes');
    return res.redirect('/auth/change-password');
  }

  const isMatch = bcrypt.compareSync(current_password, currentUser.password);
  if (!isMatch) {
    req.flash('error', 'Current password entered is incorrect');
    return res.redirect('/auth/change-password');
  }

  // Validate changes requested
  const willChangeUsername = new_username && new_username.trim() !== currentUser.username;
  const willChangePassword = new_password && new_password.trim() !== '';

  if (!willChangeUsername && !willChangePassword) {
    req.flash('error', 'No new username or password provided');
    return res.redirect('/auth/change-password');
  }

  if (willChangePassword) {
    if (new_password !== confirm_password) {
      req.flash('error', 'New passwords do not match');
      return res.redirect('/auth/change-password');
    }
    if (new_password.length < 6) {
      req.flash('error', 'New password must be at least 6 characters long');
      return res.redirect('/auth/change-password');
    }
  }

  if (willChangeUsername) {
    const existing = db.prepare('SELECT id FROM users WHERE username = ? COLLATE NOCASE AND id != ?')
      .get(new_username.trim(), currentUser.id);
    if (existing) {
      req.flash('error', `Username "${new_username.trim()}" is already taken`);
      return res.redirect('/auth/change-password');
    }
  }

  // If ADMIN user: Apply changes immediately
  if (currentUser.role === 'admin') {
    try {
      if (willChangeUsername) {
        db.prepare('UPDATE users SET username = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
          .run(new_username.trim(), currentUser.id);
        req.session.user.username = new_username.trim();
      }
      if (willChangePassword) {
        const hashedPassword = bcrypt.hashSync(new_password, 10);
        db.prepare('UPDATE users SET password = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
          .run(hashedPassword, currentUser.id);
      }
      logAudit(currentUser.id, 'ADMIN_CREDENTIALS_UPDATE', 'Admin updated credentials directly', req.ip);
      req.flash('success', 'Admin credentials updated successfully!');
      return res.redirect('/auth/change-password');
    } catch (err) {
      req.flash('error', 'Error updating credentials: ' + err.message);
      return res.redirect('/auth/change-password');
    }
  }

  // For EMPLOYEES / USERS: Submit change request requiring Admin Authorisation
  try {
    // Check if there is already a pending request
    const existingPending = db.prepare(`
      SELECT id FROM change_requests WHERE user_id = ? AND status = 'pending'
    `).get(currentUser.id);

    if (existingPending) {
      req.flash('error', 'You already have a pending change request awaiting Admin authorization.');
      return res.redirect('/auth/change-password');
    }

    let reqType = 'password';
    if (willChangeUsername && willChangePassword) reqType = 'both';
    else if (willChangeUsername) reqType = 'username';

    const requestedUsername = willChangeUsername ? new_username.trim() : null;
    const requestedPasswordHash = willChangePassword ? bcrypt.hashSync(new_password, 10) : null;

    db.prepare(`
      INSERT INTO change_requests (user_id, request_type, requested_username, requested_password, reason)
      VALUES (?, ?, ?, ?, ?)
    `).run(
      currentUser.id,
      reqType,
      requestedUsername,
      requestedPasswordHash,
      reason || 'Requested by employee'
    );

    logAudit(currentUser.id, 'SUBMIT_CHANGE_REQUEST', `Submitted ${reqType} change request awaiting Admin Authorization`, req.ip);

    req.flash('success', 'Your request has been submitted for Admin Authorization. Once reviewed and approved by the Administrator, your new credentials will be active.');
    return res.redirect('/auth/change-password');
  } catch (err) {
    console.error('Change request submission error:', err);
    req.flash('error', 'Error submitting request: ' + err.message);
    return res.redirect('/auth/change-password');
  }
});

module.exports = router;
