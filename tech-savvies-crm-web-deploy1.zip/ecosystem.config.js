module.exports = {
  apps: [
    {
      name: 'tech-savvies-crm',
      script: './server.js',
      autorestart: true,
      watch: false,
      max_memory_restart: '500M',
      env: {
        NODE_ENV: 'development',
        CRM_PORT: 3000
      },
      env_production: {
        NODE_ENV: 'production',
        CRM_PORT: 3000
      }
    },
    {
      name: 'tech-savvies-customer-portal',
      script: './server-customer.js',
      autorestart: true,
      watch: false,
      max_memory_restart: '500M',
      env: {
        NODE_ENV: 'development',
        CUSTOMER_PORT: 3001
      },
      env_production: {
        NODE_ENV: 'production',
        CUSTOMER_PORT: 3001
      }
    }
  ]
};
