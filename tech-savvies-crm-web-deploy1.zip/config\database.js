// Tech Savvies ERP Support Call CRM - Database Configuration
let Database;
try {
  // Built-in SQLite in modern Node.js (v22+) - zero compilation issues, 100% reliable
  const { DatabaseSync } = require('node:sqlite');
  Database = class DatabaseAdapter extends DatabaseSync {
    constructor(filename, options) {
      super(filename, options);
    }
    pragma(sql) {
      try {
        return this.exec(`PRAGMA ${sql};`);
      } catch (err) {
        console.warn('Pragma warning:', err.message);
      }
    }
    transaction(fn) {
      return (...args) => {
        this.exec('BEGIN TRANSACTION;');
        try {
          const res = fn(...args);
          this.exec('COMMIT;');
          return res;
        } catch (e) {
          this.exec('ROLLBACK;');
          throw e;
        }
      };
    }
  };
} catch (e) {
  Database = require('better-sqlite3');
}

const bcrypt = require('bcryptjs');
const path = require('path');
const fs = require('fs');

let DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
let DB_PATH;

// Serverless fallback for Netlify / AWS Lambda read-only filesystems
if (process.env.NETLIFY || process.env.AWS_LAMBDA_FUNCTION_NAME) {
  DATA_DIR = '/tmp';
  DB_PATH = path.join(DATA_DIR, 'techsavvies.db');
  if (!fs.existsSync(DB_PATH)) {
    const seedPath = path.join(__dirname, '..', 'data', 'techsavvies.db');
    if (fs.existsSync(seedPath)) {
      try {
        fs.copyFileSync(seedPath, DB_PATH);
      } catch (e) {
        console.error('Failed to copy seed db to /tmp:', e.message);
      }
    }
  }
} else {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  DB_PATH = path.join(DATA_DIR, 'techsavvies.db');

  // If newly mounted persistent disk has no db file, copy initial seed if available
  if (!fs.existsSync(DB_PATH)) {
    const seedPath = path.join(__dirname, '..', 'data', 'techsavvies.db');
    if (fs.existsSync(seedPath) && path.resolve(seedPath) !== path.resolve(DB_PATH)) {
      try {
        fs.copyFileSync(seedPath, DB_PATH);
        console.log('✅ Initial database seed copied to persistent disk:', DB_PATH);
      } catch (e) {
        console.warn('Seed copy note:', e.message);
      }
    }
  }
}

function initializeDatabase() {
  const db = new Database(DB_PATH, { timeout: 7000 });
  
  // Enable WAL mode for better concurrency
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');

  // ── Users Table ──
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('admin','user','employee')),
      status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected','blocked')),
      reset_token TEXT,
      reset_token_expires DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // ── Plan Versions Master Table ──
  db.exec(`
    CREATE TABLE IF NOT EXISTS plan_versions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      plan_code TEXT UNIQUE NOT NULL,
      plan_name TEXT NOT NULL,
      description TEXT,
      version_no TEXT,
      is_active INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // ── Employees Table ──
  db.exec(`
    CREATE TABLE IF NOT EXISTS employees (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER UNIQUE,
      emp_code TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT,
      designation TEXT,
      department TEXT,
      address TEXT,
      profile_pic TEXT,
      is_active INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    )
  `);

  // ── Customers Table ──
  db.exec(`
    CREATE TABLE IF NOT EXISTS customers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      customer_code TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      company TEXT,
      email TEXT,
      mobile TEXT NOT NULL,
      phone TEXT,
      plan_version TEXT,
      address TEXT,
      city TEXT,
      state TEXT,
      pincode TEXT,
      gst_no TEXT,
      password TEXT,
      portal_username TEXT,
      portal_enabled INTEGER DEFAULT 1,
      is_active INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Ensure Customer Portal columns exist on pre-existing databases
  try { db.exec(`ALTER TABLE customers ADD COLUMN password TEXT`); } catch(e) {}
  try { db.exec(`ALTER TABLE customers ADD COLUMN portal_username TEXT`); } catch(e) {}
  try { db.exec(`ALTER TABLE customers ADD COLUMN portal_enabled INTEGER DEFAULT 1`); } catch(e) {}
  try { db.exec(`ALTER TABLE call_records ADD COLUMN source TEXT DEFAULT 'call'`); } catch(e) {}

  // ── Issues Master Table ──
  db.exec(`
    CREATE TABLE IF NOT EXISTS issues_master (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      issue_code TEXT UNIQUE NOT NULL,
      category TEXT NOT NULL,
      sub_category TEXT,
      description TEXT NOT NULL,
      priority TEXT DEFAULT 'medium' CHECK(priority IN ('low','medium','high','critical')),
      estimated_time INTEGER DEFAULT 30,
      is_active INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // ── Call Records Table ──
  db.exec(`
    CREATE TABLE IF NOT EXISTS call_records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ticket_no TEXT UNIQUE NOT NULL,
      customer_id INTEGER NOT NULL,
      employee_id INTEGER,
      call_date DATE NOT NULL,
      call_time TIME NOT NULL,
      duration INTEGER DEFAULT 0,
      plan_version TEXT,
      issue_id INTEGER,
      issue_description TEXT,
      status TEXT DEFAULT 'open' CHECK(status IN ('open','assigned','in_progress','resolved','escalated','closed')),
      resolution_notes TEXT,
      resolved_at DATETIME,
      resolved_by INTEGER,
      created_by INTEGER,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (customer_id) REFERENCES customers(id),
      FOREIGN KEY (employee_id) REFERENCES employees(id),
      FOREIGN KEY (issue_id) REFERENCES issues_master(id),
      FOREIGN KEY (resolved_by) REFERENCES employees(id),
      FOREIGN KEY (created_by) REFERENCES users(id)
    )
  `);

  // ── Call Allocations Table ──
  db.exec(`
    CREATE TABLE IF NOT EXISTS call_allocations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      call_record_id INTEGER NOT NULL,
      allocated_to INTEGER NOT NULL,
      allocated_by INTEGER NOT NULL,
      allocated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      status TEXT DEFAULT 'assigned' CHECK(status IN ('assigned','accepted','in_progress','completed','reassigned')),
      notes TEXT,
      FOREIGN KEY (call_record_id) REFERENCES call_records(id),
      FOREIGN KEY (allocated_to) REFERENCES employees(id),
      FOREIGN KEY (allocated_by) REFERENCES users(id)
    )
  `);

  // ── Escalations Table ──
  db.exec(`
    CREATE TABLE IF NOT EXISTS escalations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      call_record_id INTEGER NOT NULL,
      escalated_from INTEGER,
      escalated_to INTEGER,
      reason TEXT NOT NULL,
      priority TEXT DEFAULT 'high' CHECK(priority IN ('medium','high','critical')),
      status TEXT DEFAULT 'pending' CHECK(status IN ('pending','assigned','resolved')),
      resolution_notes TEXT,
      escalated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      resolved_at DATETIME,
      FOREIGN KEY (call_record_id) REFERENCES call_records(id),
      FOREIGN KEY (escalated_from) REFERENCES employees(id),
      FOREIGN KEY (escalated_to) REFERENCES employees(id)
    )
  `);

  // ── Notifications Table ──
  db.exec(`
    CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      call_record_id INTEGER,
      customer_id INTEGER,
      type TEXT NOT NULL CHECK(type IN ('sms','email')),
      recipient TEXT NOT NULL,
      subject TEXT,
      message TEXT NOT NULL,
      status TEXT DEFAULT 'pending' CHECK(status IN ('pending','sent','failed')),
      sent_at DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (call_record_id) REFERENCES call_records(id),
      FOREIGN KEY (customer_id) REFERENCES customers(id)
    )
  `);

  // ── Activity Log (Audit Log) Table ──
  db.exec(`
    CREATE TABLE IF NOT EXISTS activity_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      action TEXT NOT NULL,
      details TEXT,
      ip_address TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id)
    )
  `);

  // ── User Change Requests Table (Username & Password requiring Admin Authorization) ──
  db.exec(`
    CREATE TABLE IF NOT EXISTS change_requests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      request_type TEXT NOT NULL CHECK(request_type IN ('username','password','both')),
      requested_username TEXT,
      requested_password TEXT,
      reason TEXT,
      status TEXT DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),
      admin_notes TEXT,
      reviewed_by INTEGER,
      reviewed_at DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id),
      FOREIGN KEY (reviewed_by) REFERENCES users(id)
    )
  `);

  // ── Create Default Admin User ──
  const adminExists = db.prepare('SELECT id FROM users WHERE username = ?').get('ADMIN');
  if (!adminExists) {
    const hashedPassword = bcrypt.hashSync('Admin@123', 10);
    db.prepare(`
      INSERT INTO users (username, email, password, role, status) 
      VALUES (?, ?, ?, ?, ?)
    `).run('ADMIN', 'admin@techsavvies.com', hashedPassword, 'admin', 'approved');
    
    console.log('✅ Default admin user created: ADMIN / Admin@123');
  }

  // ── Seed Default Plan Versions ──
  const planCount = db.prepare('SELECT COUNT(*) as cnt FROM plan_versions').get();
  if (planCount.cnt === 0) {
    const defaultPlans = [
      ['PLN001', 'ERP Starter Lite', 'Entry level package for small business operations', 'v1.0'],
      ['PLN002', 'ERP Standard Pro', 'Standard multi-user commercial ERP solution', 'v2.4'],
      ['PLN003', 'ERP Enterprise Suite', 'Full-fledged enterprise suite with inventory, manufacturing and HR', 'v3.5'],
      ['PLN004', 'ERP Cloud Ultimate', 'Cloud multi-branch real-time sync ERP solution', 'v4.0']
    ];
    const stmtPlan = db.prepare('INSERT INTO plan_versions (plan_code, plan_name, description, version_no) VALUES (?,?,?,?)');
    for (const p of defaultPlans) {
      stmtPlan.run(...p);
    }
    console.log('✅ Default Plan Versions initialized');
  }

  // ── Seed Sample Issue Categories ──
  const issueCount = db.prepare('SELECT COUNT(*) as cnt FROM issues_master').get();
  if (issueCount.cnt === 0) {
    const issues = [
      ['ISS001', 'ERP Module', 'Login', 'Unable to login to ERP system', 'high', 15],
      ['ISS002', 'ERP Module', 'Reports', 'Reports not generating correctly', 'medium', 30],
      ['ISS003', 'ERP Module', 'Invoice', 'Invoice printing error', 'medium', 20],
      ['ISS004', 'ERP Module', 'Inventory', 'Stock mismatch in inventory module', 'high', 45],
      ['ISS005', 'ERP Module', 'Payroll', 'Salary calculation error', 'critical', 60],
      ['ISS006', 'Technical', 'Server', 'Server connectivity issues', 'critical', 30],
      ['ISS007', 'Technical', 'Database', 'Database backup failure', 'high', 45],
      ['ISS008', 'Technical', 'Network', 'Network connectivity problem', 'high', 20],
      ['ISS009', 'Installation', 'Setup', 'Software installation issues', 'medium', 60],
      ['ISS010', 'General', 'Training', 'User training required', 'low', 120],
      ['ISS011', 'ERP Module', 'GST', 'GST filing/return errors', 'high', 30],
      ['ISS012', 'ERP Module', 'Purchase', 'Purchase order processing error', 'medium', 25],
    ];
    const stmt = db.prepare('INSERT INTO issues_master (issue_code, category, sub_category, description, priority, estimated_time) VALUES (?,?,?,?,?,?)');
    for (const issue of issues) {
      stmt.run(...issue);
    }
    console.log('✅ Sample issue categories created');
  }

  return db;
}

// Get DB instance (singleton)
let dbInstance = null;
function getDb() {
  if (!dbInstance) {
    dbInstance = initializeDatabase();
  }
  return dbInstance;
}

// Audit Log Helper
function logAudit(userId, action, details, ipAddress = '') {
  try {
    const db = getDb();
    db.prepare(`
      INSERT INTO activity_log (user_id, action, details, ip_address)
      VALUES (?, ?, ?, ?)
    `).run(userId || null, action, details || '', ipAddress || '');
  } catch (err) {
    console.error('Audit Log Error:', err.message);
  }
}

// Generate unique ticket number
function generateTicketNo() {
  const db = getDb();
  const today = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const lastTicket = db.prepare(
    "SELECT ticket_no FROM call_records WHERE ticket_no LIKE ? ORDER BY id DESC LIMIT 1"
  ).get(`TKT${today}%`);
  
  let seq = 1;
  if (lastTicket) {
    seq = parseInt(lastTicket.ticket_no.slice(-4)) + 1;
  }
  return `TKT${today}${String(seq).padStart(4, '0')}`;
}

// Generate unique codes
function generateCode(prefix, table, field) {
  const db = getDb();
  const last = db.prepare(`SELECT ${field} FROM ${table} ORDER BY id DESC LIMIT 1`).get();
  let seq = 1;
  if (last && last[field]) {
    const num = parseInt(last[field].replace(prefix, ''));
    if (!isNaN(num)) seq = num + 1;
  }
  return `${prefix}${String(seq).padStart(4, '0')}`;
}

module.exports = { getDb, initializeDatabase, generateTicketNo, generateCode, logAudit };
