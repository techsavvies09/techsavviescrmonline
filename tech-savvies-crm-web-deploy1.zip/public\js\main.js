document.addEventListener('DOMContentLoaded', function() {
  // Auto-dismiss flash alerts after 5 seconds
  setTimeout(function() {
    document.querySelectorAll('.flash-messages .alert').forEach(function(alert) {
      var bsAlert = new bootstrap.Alert(alert);
      bsAlert.close();
    });
  }, 5000);

  // Sidebar active link highlighting
  var currentPath = window.location.pathname;
  document.querySelectorAll('.sidebar-link').forEach(function(link) {
    if (link.getAttribute('href') === currentPath) {
      link.classList.add('active');
    }
  });

  // Confirm dialogs for dangerous actions
  document.querySelectorAll('[data-confirm]').forEach(function(el) {
    el.addEventListener('click', function(e) {
      if (!confirm(el.getAttribute('data-confirm') || 'Are you sure?')) {
        e.preventDefault();
      }
    });
  });

  // Set date inputs to today if empty
  document.querySelectorAll('input[type="date"]').forEach(function(input) {
    if (!input.value && !input.dataset.noDefault) {
      input.value = new Date().toISOString().split('T')[0];
    }
  });

  // Set time inputs to now if empty  
  document.querySelectorAll('input[type="time"]').forEach(function(input) {
    if (!input.value && !input.dataset.noDefault) {
      var now = new Date();
      input.value = now.getHours().toString().padStart(2,'0') + ':' + now.getMinutes().toString().padStart(2,'0');
    }
  });

  // Mobile sidebar toggle
  var toggler = document.querySelector('.navbar-toggler');
  if (toggler) {
    toggler.addEventListener('click', function() {
      var sidebar = document.getElementById('sidebar');
      if (sidebar) sidebar.classList.toggle('show');
    });
  }

  // Password confirm validation
  var confirmPw = document.getElementById('confirm_password');
  var newPw = document.getElementById('new_password');
  if (confirmPw && newPw) {
    confirmPw.addEventListener('input', function() {
      if (confirmPw.value !== newPw.value) {
        confirmPw.setCustomValidity('Passwords do not match');
      } else {
        confirmPw.setCustomValidity('');
      }
    });
  }
});

function printReport() { window.print(); }
