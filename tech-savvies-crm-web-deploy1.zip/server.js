// Tech Savvies ERP Support Call CRM - Staff & Admin Management Server
require('dotenv').config();
const express = require('express');
const session = require('express-session');
const flash = require('connect-flash');
const path = require('path');
const multer = require('multer');
const fs = require('fs');
const { initializeDatabase } = require('./config/database');

const app = express();
const PORT = process.env.CRM_PORT || process.env.PORT || 3000;
const CUSTOMER_URL = process.env.CUSTOMER_URL || 'http://localhost:3001';

// Trust reverse proxy (for Render, Railway, Nginx, Cloudflare, AWS, Heroku)
app.set('trust proxy', 1);

// Initialize database
initializeDatabase();

// View engine setup
const viewsPath = fs.existsSync(path.join(__dirname, 'views'))
  ? path.join(__dirname, 'views')
  : path.resolve(process.cwd(), 'views');
app.set('view engine', 'ejs');
app.set('views', viewsPath);

// Middleware
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Session configuration
app.use(session({
  name: 'techsavvies_crm_sid',
  secret: process.env.SESSION_SECRET || 'tech_savvies_secret_2024',
  resave: false,
  saveUninitialized: false,
  cookie: { 
    secure: 'auto', // Automatically uses secure cookies when accessed via HTTPS/SSL
    maxAge: 24 * 60 * 60 * 1000 // 24 hours
  }
}));

// Flash messages
app.use(flash());

// Auth middleware for all views
const { setLocals } = require('./middleware/auth');
app.use(setLocals);

// File upload configuration
const uploadsDir = path.join(__dirname, 'public', 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Mount Customer Portal & Complaint Routes
app.use('/customer', require('./routes/customer'));

// Convenient direct shortcuts
app.get('/complaint', (req, res) => res.redirect('/customer/complaint'));
app.get('/track', (req, res) => res.redirect('/customer/track'));

// CRM Staff & Admin Routes
app.use('/auth', require('./routes/auth'));
app.use('/admin', require('./routes/admin'));
app.use('/employee', require('./routes/employee'));
app.use('/reports', require('./routes/reports'));

// Home route - redirect to active session or login
app.get('/', (req, res) => {
  if (req.session && req.session.customer) {
    return res.redirect('/customer/dashboard');
  }
  if (req.session && req.session.user) {
    if (req.session.user.role === 'admin') {
      return res.redirect('/admin/dashboard');
    } else {
      return res.redirect('/employee/dashboard');
    }
  }
  res.redirect('/auth/login');
});

// 404 handler
app.use((req, res) => {
  res.status(404).render('partials/404', { title: 'Page Not Found' });
});

// Error handler
app.use((err, req, res, next) => {
  console.error('CRM Server error:', err.stack);
  res.status(500).render('partials/error', { title: 'Server Error', error: err.message });
});

// Start CRM server only when run directly (not as a serverless function)
if (require.main === module && !process.env.NETLIFY) {
  app.listen(PORT, () => {
    console.log(`
╔══════════════════════════════════════════════════════╗
║                                                      ║
║   🚀 Tech Savvies ERP Support CRM Server Ready       ║
║                                                      ║
║   CRM Staff Portal:      http://localhost:${PORT}      ║
║   Customer Complaint:    http://localhost:${PORT}/customer/complaint
║   Customer Login:        http://localhost:${PORT}/customer/login
║   Default Admin Login:   ADMIN / Admin@123           ║
║                                                      ║
╚══════════════════════════════════════════════════════╝
    `);
  });
}

module.exports = app;
