// Tech Savvies ERP Support Call CRM - Authentication Middleware
function isAuthenticated(req, res, next) {
  if (req.session && req.session.user) {
    return next();
  }
  req.flash('error', 'Please login to continue');
  res.redirect('/auth/login');
}

function isAdmin(req, res, next) {
  if (req.session && req.session.user && req.session.user.role === 'admin') {
    return next();
  }
  req.flash('error', 'Access denied. Admin privileges required.');
  res.redirect('/auth/login');
}

function isEmployee(req, res, next) {
  if (req.session && req.session.user && 
      (req.session.user.role === 'employee' || req.session.user.role === 'admin')) {
    return next();
  }
  req.flash('error', 'Access denied. Employee login required.');
  res.redirect('/auth/login');
}

function isApproved(req, res, next) {
  if (req.session && req.session.user && req.session.user.status === 'approved') {
    return next();
  }
  req.flash('error', 'Your account is pending approval. Please contact admin.');
  res.redirect('/auth/login');
}

function isCustomer(req, res, next) {
  if (req.session && req.session.customer) {
    return next();
  }
  req.flash('error', 'Please login to access the Customer Portal.');
  res.redirect('/customer/login');
}

// Make user data and portal URLs available to all views
function setLocals(req, res, next) {
  res.locals.user = req.session.user || null;
  res.locals.customer = req.session.customer || null;
  res.locals.success = req.flash('success');
  res.locals.error = req.flash('error');
  res.locals.info = req.flash('info');
  res.locals.customerPortalUrl = process.env.CUSTOMER_URL || '';
  res.locals.crmUrl = process.env.CRM_URL || '';
  next();
}

module.exports = { isAuthenticated, isAdmin, isEmployee, isApproved, isCustomer, setLocals };
