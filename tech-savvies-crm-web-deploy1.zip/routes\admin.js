// Tech Savvies ERP Support Call CRM - Admin Routes
const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const { isAuthenticated, isAdmin } = require('../middleware/auth');
const { getDb, generateTicketNo, generateCode, logAudit } = require('../config/database');
const { sendResolutionNotification } = require('../config/notifications');

// Apply auth middleware to all admin routes
router.use(isAuthenticated, isAdmin);

// ═══════════════════════════════════════════════════
//  DASHBOARD
// ═══════════════════════════════════════════════════
router.get('/dashboard', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const today = new Date().toISOString().slice(0, 10);

  const totalCallsToday = db.prepare(
    "SELECT COUNT(*) as count FROM call_records WHERE call_date = ?"
  ).get(today)?.count || 0;

  const pendingCalls = db.prepare(
    "SELECT COUNT(*) as count FROM call_records WHERE status IN ('open','assigned','in_progress')"
  ).get()?.count || 0;

  const resolvedCalls = db.prepare(
    "SELECT COUNT(*) as count FROM call_records WHERE status = 'resolved'"
  ).get()?.count || 0;

  const escalatedCalls = db.prepare(
    "SELECT COUNT(*) as count FROM call_records WHERE status = 'escalated'"
  ).get()?.count || 0;

  const totalCustomers = db.prepare(
    "SELECT COUNT(*) as count FROM customers"
  ).get()?.count || 0;

  const totalEmployees = db.prepare(
    "SELECT COUNT(*) as count FROM employees"
  ).get()?.count || 0;

  const pendingRequests = db.prepare(
    "SELECT COUNT(*) as count FROM change_requests WHERE status = 'pending'"
  ).get()?.count || 0;

  const recentCalls = db.prepare(`
    SELECT cr.*, c.name as customer_name, c.company,
           e.name as employee_name, im.category, im.sub_category
    FROM call_records cr
    LEFT JOIN customers c ON cr.customer_id = c.id
    LEFT JOIN employees e ON cr.employee_id = e.id
    LEFT JOIN issues_master im ON cr.issue_id = im.id
    ORDER BY cr.created_at DESC LIMIT 10
  `).all();

  res.render('admin/dashboard', {
    stats: {
      totalCallsToday,
      pending: pendingCalls,
      pendingCalls,
      resolved: resolvedCalls,
      resolvedCalls,
      escalated: escalatedCalls,
      escalatedCalls,
      totalCustomers,
      totalEmployees,
      pendingRequests
    },
    recentCalls
  });
});

// ═══════════════════════════════════════════════════
//  USER MANAGEMENT & APPROVAL CONSOLE
// ═══════════════════════════════════════════════════
router.get('/users', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const users = db.prepare(`
    SELECT u.*, e.id as linked_emp_id, e.emp_code as linked_emp_code, e.name as linked_emp_name
    FROM users u
    LEFT JOIN employees e ON u.id = e.user_id
    ORDER BY u.created_at DESC
  `).all();
  res.render('admin/users', { users });
});

router.post('/users/:id/approve', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(req.params.id);
  db.prepare("UPDATE users SET status = 'approved', updated_at = CURRENT_TIMESTAMP WHERE id = ?").run(req.params.id);
  logAudit(req.session.user.id, 'APPROVE_USER', `Approved user registration for ${user ? user.username : req.params.id}`, req.ip);
  req.flash('success', 'User approved successfully');
  res.redirect('/admin/users');
});

router.post('/users/:id/reject', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(req.params.id);
  db.prepare("UPDATE users SET status = 'rejected', updated_at = CURRENT_TIMESTAMP WHERE id = ?").run(req.params.id);
  logAudit(req.session.user.id, 'REJECT_USER', `Rejected user registration for ${user ? user.username : req.params.id}`, req.ip);
  req.flash('success', 'User rejected');
  res.redirect('/admin/users');
});

router.post('/users/:id/block', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(req.params.id);
  db.prepare("UPDATE users SET status = 'blocked', updated_at = CURRENT_TIMESTAMP WHERE id = ?").run(req.params.id);
  logAudit(req.session.user.id, 'BLOCK_USER', `Blocked user ${user ? user.username : req.params.id}`, req.ip);
  req.flash('success', 'User blocked');
  res.redirect('/admin/users');
});

// Map registered user directly into Employee Master
router.post('/users/:id/map-employee', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(req.params.id);

  if (!user) {
    req.flash('error', 'User not found');
    return res.redirect('/admin/users');
  }

  const existingEmp = db.prepare("SELECT id, emp_code FROM employees WHERE user_id = ?").get(user.id);
  if (existingEmp) {
    req.flash('info', `User is already mapped to employee (${existingEmp.emp_code})`);
    return res.redirect('/admin/employees/edit/' + existingEmp.id);
  }

  try {
    const empCode = generateCode('EMP', 'employees', 'emp_code');
    const mapTx = db.transaction(() => {
      // 1. Ensure user status is approved and role is employee
      db.prepare("UPDATE users SET role = 'employee', status = 'approved', updated_at = CURRENT_TIMESTAMP WHERE id = ?")
        .run(user.id);

      // 2. Create employee profile
      db.prepare(`
        INSERT INTO employees (user_id, emp_code, name, email, phone, designation, department, address)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        user.id,
        empCode,
        user.username,
        user.email,
        '',
        'Support Engineer',
        'Technical Support',
        ''
      );
    });

    mapTx();

    logAudit(req.session.user.id, 'MAP_USER_EMPLOYEE', `Mapped user ${user.username} to new employee ${empCode}`, req.ip);
    req.flash('success', `User "${user.username}" successfully mapped to Employee profile (${empCode})! You can now refine employee details.`);
    res.redirect('/admin/employees');
  } catch (err) {
    req.flash('error', 'Error mapping user to employee: ' + err.message);
    res.redirect('/admin/users');
  }
});

// ═══════════════════════════════════════════════════
//  USER CHANGE REQUESTS (Username & Password Authorization)
// ═══════════════════════════════════════════════════
router.get('/change-requests', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const requests = db.prepare(`
    SELECT cr.*, u.username as current_username, u.email as user_email, u.role as user_role,
           rv.username as reviewer_username
    FROM change_requests cr
    JOIN users u ON cr.user_id = u.id
    LEFT JOIN users rv ON cr.reviewed_by = rv.id
    ORDER BY cr.created_at DESC
  `).all();

  res.render('admin/change-requests', { requests });
});

router.post('/change-requests/:id/approve', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const request = db.prepare('SELECT * FROM change_requests WHERE id = ?').get(req.params.id);

  if (!request || request.status !== 'pending') {
    req.flash('error', 'Request not found or already processed');
    return res.redirect('/admin/change-requests');
  }

  try {
    const adminNotes = req.body.admin_notes || 'Approved by Admin';

    const approveTx = db.transaction(() => {
      if (request.request_type === 'username' || request.request_type === 'both') {
        if (request.requested_username) {
          const exists = db.prepare('SELECT id FROM users WHERE username = ? AND id != ?').get(request.requested_username, request.user_id);
          if (exists) {
            throw new Error(`Username "${request.requested_username}" is already taken.`);
          }
          db.prepare('UPDATE users SET username = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
            .run(request.requested_username, request.user_id);
        }
      }

      if (request.request_type === 'password' || request.request_type === 'both') {
        if (request.requested_password) {
          db.prepare('UPDATE users SET password = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
            .run(request.requested_password, request.user_id);
        }
      }

      db.prepare(`
        UPDATE change_requests 
        SET status = 'approved', admin_notes = ?, reviewed_by = ?, reviewed_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(adminNotes, req.session.user.id, request.id);
    });

    approveTx();

    logAudit(req.session.user.id, 'APPROVE_CHANGE_REQUEST', `Approved ${request.request_type} change request #${request.id} for user ID ${request.user_id}`, req.ip);

    req.flash('success', 'User credentials change request approved and applied successfully');
    res.redirect('/admin/change-requests');
  } catch (err) {
    req.flash('error', 'Error approving request: ' + err.message);
    res.redirect('/admin/change-requests');
  }
});

router.post('/change-requests/:id/reject', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const adminNotes = req.body.admin_notes || 'Rejected by Admin';

  try {
    db.prepare(`
      UPDATE change_requests 
      SET status = 'rejected', admin_notes = ?, reviewed_by = ?, reviewed_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(adminNotes, req.session.user.id, req.params.id);

    logAudit(req.session.user.id, 'REJECT_CHANGE_REQUEST', `Rejected change request #${req.params.id}`, req.ip);

    req.flash('success', 'Change request rejected');
    res.redirect('/admin/change-requests');
  } catch (err) {
    req.flash('error', 'Error rejecting request: ' + err.message);
    res.redirect('/admin/change-requests');
  }
});

// ═══════════════════════════════════════════════════
//  PLAN VERSION MASTER CRUD
// ═══════════════════════════════════════════════════
router.get('/plans', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const plans = db.prepare('SELECT * FROM plan_versions ORDER BY id DESC').all();
  res.render('admin/plans', { plans });
});

router.get('/plans/add', isAuthenticated, isAdmin, (req, res) => {
  res.render('admin/plan-form', { isEdit: false, plan: {} });
});

router.post('/plans/add', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const { plan_name, description, version_no } = req.body;
  const plan_code = generateCode('PLN', 'plan_versions', 'plan_code');

  try {
    db.prepare(`
      INSERT INTO plan_versions (plan_code, plan_name, description, version_no)
      VALUES (?, ?, ?, ?)
    `).run(plan_code, plan_name.trim(), description || '', version_no || 'v1.0');

    logAudit(req.session.user.id, 'CREATE_PLAN', `Created plan ${plan_code} - ${plan_name}`, req.ip);

    req.flash('success', `Plan version "${plan_name}" created successfully`);
    res.redirect('/admin/plans');
  } catch (err) {
    req.flash('error', 'Error creating plan version: ' + err.message);
    res.redirect('/admin/plans/add');
  }
});

router.get('/plans/edit/:id', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const plan = db.prepare('SELECT * FROM plan_versions WHERE id = ?').get(req.params.id);
  if (!plan) {
    req.flash('error', 'Plan version not found');
    return res.redirect('/admin/plans');
  }
  res.render('admin/plan-form', { isEdit: true, plan });
});

router.post('/plans/edit/:id', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const { plan_name, description, version_no, is_active } = req.body;

  try {
    db.prepare(`
      UPDATE plan_versions 
      SET plan_name = ?, description = ?, version_no = ?, is_active = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(plan_name.trim(), description || '', version_no || 'v1.0', is_active ? 1 : 0, req.params.id);

    logAudit(req.session.user.id, 'UPDATE_PLAN', `Updated plan version #${req.params.id} (${plan_name})`, req.ip);

    req.flash('success', 'Plan version updated successfully');
    res.redirect('/admin/plans');
  } catch (err) {
    req.flash('error', 'Error updating plan version: ' + err.message);
    res.redirect('/admin/plans/edit/' + req.params.id);
  }
});

// ═══════════════════════════════════════════════════
//  CUSTOMERS MASTER
// ═══════════════════════════════════════════════════
router.get('/customers', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const customers = db.prepare("SELECT * FROM customers ORDER BY created_at DESC").all();
  res.render('admin/customers', { customers });
});

router.get('/customers/add', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const plans = db.prepare("SELECT plan_name FROM plan_versions WHERE is_active = 1 ORDER BY plan_name").all();
  res.render('admin/customer-form', { customer: {}, isEdit: false, plans });
});

router.post('/customers/add', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const { name, company, email, mobile, phone, plan_version, address, city, state, pincode, gst_no } = req.body;
  const customer_code = generateCode('CUS', 'customers', 'customer_code');

  try {
    db.prepare(`
      INSERT INTO customers (customer_code, name, company, email, mobile, phone, plan_version, address, city, state, pincode, gst_no)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(customer_code, name, company, email, mobile, phone, plan_version, address, city, state, pincode, gst_no);

    logAudit(req.session.user.id, 'CREATE_CUSTOMER', `Created customer ${customer_code} - ${name}`, req.ip);
    req.flash('success', `Customer ${name} added successfully (Code: ${customer_code})`);
    res.redirect('/admin/customers');
  } catch (err) {
    req.flash('error', 'Error adding customer: ' + err.message);
    res.redirect('/admin/customers/add');
  }
});

router.get('/customers/edit/:id', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const customer = db.prepare("SELECT * FROM customers WHERE id = ?").get(req.params.id);
  if (!customer) {
    req.flash('error', 'Customer not found');
    return res.redirect('/admin/customers');
  }
  const plans = db.prepare("SELECT plan_name FROM plan_versions WHERE is_active = 1 ORDER BY plan_name").all();
  res.render('admin/customer-form', { customer, isEdit: true, plans });
});

router.post('/customers/edit/:id', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const { name, company, email, mobile, phone, plan_version, address, city, state, pincode, gst_no } = req.body;

  try {
    db.prepare(`
      UPDATE customers 
      SET name=?, company=?, email=?, mobile=?, phone=?, plan_version=?, address=?, city=?, state=?, pincode=?, gst_no=?, updated_at=CURRENT_TIMESTAMP
      WHERE id=?
    `).run(name, company, email, mobile, phone, plan_version, address, city, state, pincode, gst_no, req.params.id);

    logAudit(req.session.user.id, 'UPDATE_CUSTOMER', `Updated customer #${req.params.id} (${name})`, req.ip);
    req.flash('success', 'Customer updated successfully');
    res.redirect('/admin/customers');
  } catch (err) {
    req.flash('error', 'Error updating customer: ' + err.message);
    res.redirect('/admin/customers/edit/' + req.params.id);
  }
});

// ═══════════════════════════════════════════════════
//  EMPLOYEES MASTER (Admin Only)
// ═══════════════════════════════════════════════════
router.get('/employees', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const employees = db.prepare(`
    SELECT e.*, u.username, u.status as user_status
    FROM employees e
    LEFT JOIN users u ON e.user_id = u.id
    ORDER BY e.created_at DESC
  `).all();
  res.render('admin/employees', { employees });
});

router.get('/employees/add', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  // Fetch registered users not yet mapped to any employee
  const unmappedUsers = db.prepare(`
    SELECT u.id, u.username, u.email, u.role, u.status
    FROM users u
    LEFT JOIN employees e ON u.id = e.user_id
    WHERE e.id IS NULL AND u.role != 'admin'
    ORDER BY u.username ASC
  `).all();

  res.render('admin/employee-form', { employee: {}, isEdit: false, unmappedUsers });
});

router.post('/employees/add', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const { name, email, phone, designation, department, address, creation_mode, existing_user_id, username, password } = req.body;
  const emp_code = generateCode('EMP', 'employees', 'emp_code');

  try {
    let assignedUserId = null;

    if (creation_mode === 'map_existing' && existing_user_id) {
      // Map existing user
      assignedUserId = parseInt(existing_user_id);
      db.prepare("UPDATE users SET role = 'employee', status = 'approved', updated_at = CURRENT_TIMESTAMP WHERE id = ?")
        .run(assignedUserId);
    } else {
      // Create new login account
      const existingUser = db.prepare("SELECT id FROM users WHERE username = ?").get(username);
      if (existingUser) {
        req.flash('error', 'Username already exists. Please choose another or map to existing user.');
        return res.redirect('/admin/employees/add');
      }

      const hashedPassword = bcrypt.hashSync(password || 'Emp@123', 10);
      const userResult = db.prepare(`
        INSERT INTO users (username, email, password, role, status)
        VALUES (?, ?, ?, 'employee', 'approved')
      `).run(username, email, hashedPassword);
      assignedUserId = userResult.lastInsertRowid;
    }

    db.prepare(`
      INSERT INTO employees (user_id, emp_code, name, email, phone, designation, department, address)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(assignedUserId, emp_code, name, email, phone, designation, department, address);

    logAudit(req.session.user.id, 'CREATE_EMPLOYEE', `Created employee ${emp_code} - ${name} (User ID: ${assignedUserId})`, req.ip);

    req.flash('success', `Employee ${name} saved successfully (Code: ${emp_code})`);
    res.redirect('/admin/employees');
  } catch (err) {
    req.flash('error', 'Error creating employee: ' + err.message);
    res.redirect('/admin/employees/add');
  }
});

router.get('/employees/edit/:id', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const employee = db.prepare(`
    SELECT e.*, u.username
    FROM employees e
    LEFT JOIN users u ON e.user_id = u.id
    WHERE e.id = ?
  `).get(req.params.id);

  if (!employee) {
    req.flash('error', 'Employee not found');
    return res.redirect('/admin/employees');
  }

  // Also pass available unmapped users in case admin wants to link/re-link user
  const unmappedUsers = db.prepare(`
    SELECT u.id, u.username, u.email
    FROM users u
    LEFT JOIN employees e ON u.id = e.user_id
    WHERE (e.id IS NULL OR u.id = ?) AND u.role != 'admin'
    ORDER BY u.username ASC
  `).all(employee.user_id || -1);

  res.render('admin/employee-form', { employee, isEdit: true, unmappedUsers });
});

router.post('/employees/edit/:id', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const { name, email, phone, designation, department, address, user_id } = req.body;

  try {
    const updatedUserId = user_id ? parseInt(user_id) : null;
    
    db.prepare(`
      UPDATE employees 
      SET name=?, email=?, phone=?, designation=?, department=?, address=?, user_id=?, updated_at=CURRENT_TIMESTAMP
      WHERE id=?
    `).run(name, email, phone, designation, department, address, updatedUserId, req.params.id);

    if (updatedUserId) {
      db.prepare("UPDATE users SET role = 'employee', status = 'approved', updated_at = CURRENT_TIMESTAMP WHERE id = ?")
        .run(updatedUserId);
    }

    logAudit(req.session.user.id, 'UPDATE_EMPLOYEE', `Updated employee #${req.params.id} (${name})`, req.ip);

    req.flash('success', 'Employee updated successfully');
    res.redirect('/admin/employees');
  } catch (err) {
    req.flash('error', 'Error updating employee: ' + err.message);
    res.redirect('/admin/employees/edit/' + req.params.id);
  }
});

// ═══════════════════════════════════════════════════
//  ISSUES MASTER
// ═══════════════════════════════════════════════════
router.get('/issues', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const issues = db.prepare("SELECT * FROM issues_master ORDER BY category, sub_category").all();
  res.render('admin/issues', { issues });
});

router.get('/issues/add', isAuthenticated, isAdmin, (req, res) => {
  res.render('admin/issue-form', { issue: {}, isEdit: false });
});

router.post('/issues/add', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const { category, sub_category, description, priority, estimated_time } = req.body;
  const issue_code = generateCode('ISS', 'issues_master', 'issue_code');

  try {
    db.prepare(`
      INSERT INTO issues_master (issue_code, category, sub_category, description, priority, estimated_time)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(issue_code, category, sub_category, description, priority || 'medium', parseInt(estimated_time) || 30);

    logAudit(req.session.user.id, 'CREATE_ISSUE', `Created issue master ${issue_code} - ${category}/${sub_category}`, req.ip);
    req.flash('success', `Issue type added successfully (Code: ${issue_code})`);
    res.redirect('/admin/issues');
  } catch (err) {
    req.flash('error', 'Error adding issue: ' + err.message);
    res.redirect('/admin/issues/add');
  }
});

router.get('/issues/edit/:id', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const issue = db.prepare("SELECT * FROM issues_master WHERE id = ?").get(req.params.id);
  if (!issue) {
    req.flash('error', 'Issue not found');
    return res.redirect('/admin/issues');
  }
  res.render('admin/issue-form', { issue, isEdit: true });
});

router.post('/issues/edit/:id', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const { category, sub_category, description, priority, estimated_time } = req.body;

  try {
    db.prepare(`
      UPDATE issues_master 
      SET category=?, sub_category=?, description=?, priority=?, estimated_time=?
      WHERE id=?
    `).run(category, sub_category, description, priority, parseInt(estimated_time) || 30, req.params.id);

    logAudit(req.session.user.id, 'UPDATE_ISSUE', `Updated issue #${req.params.id}`, req.ip);
    req.flash('success', 'Issue updated successfully');
    res.redirect('/admin/issues');
  } catch (err) {
    req.flash('error', 'Error updating issue: ' + err.message);
    res.redirect('/admin/issues/edit/' + req.params.id);
  }
});

// ═══════════════════════════════════════════════════
//  CALL RECORDS (LIST, ADD, EDIT, VIEW, RESOLVE, DELETE)
// ═══════════════════════════════════════════════════
router.get('/calls', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const { date, status, employee_id } = req.query;

  let sql = `
    SELECT cr.*, c.name as customer_name, c.company, c.mobile as customer_mobile,
           e.name as employee_name, im.category, im.sub_category, im.description as issue_name
    FROM call_records cr
    LEFT JOIN customers c ON cr.customer_id = c.id
    LEFT JOIN employees e ON cr.employee_id = e.id
    LEFT JOIN issues_master im ON cr.issue_id = im.id
    WHERE 1=1
  `;
  const params = [];

  if (date) {
    sql += " AND cr.call_date = ?";
    params.push(date);
  }
  if (status) {
    sql += " AND cr.status = ?";
    params.push(status);
  }
  if (employee_id) {
    sql += " AND cr.employee_id = ?";
    params.push(employee_id);
  }

  sql += " ORDER BY cr.created_at DESC";

  const calls = db.prepare(sql).all(...params);
  const employees = db.prepare("SELECT id, name FROM employees WHERE is_active = 1 ORDER BY name").all();

  res.render('admin/calls', { calls, employees, filters: { date: date || '', status: status || '', employee_id: employee_id || '' } });
});

router.get('/calls/add', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const customers = db.prepare("SELECT id, name, company, customer_code, plan_version FROM customers WHERE is_active = 1 ORDER BY name").all();
  const issues = db.prepare("SELECT id, category, sub_category, description FROM issues_master WHERE is_active = 1 ORDER BY category, sub_category").all();
  const plans = db.prepare("SELECT plan_name FROM plan_versions WHERE is_active = 1 ORDER BY plan_name").all();
  res.render('admin/call-form', { isEdit: false, call: {}, customers, issues, plans });
});

router.post('/calls/add', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const { customer_id, call_date, call_time, duration, plan_version, issue_id, issue_description } = req.body;
  const ticket_no = generateTicketNo();

  try {
    db.prepare(`
      INSERT INTO call_records (ticket_no, customer_id, call_date, call_time, duration, plan_version, issue_id, issue_description, status, created_by)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'open', ?)
    `).run(
      ticket_no,
      customer_id,
      call_date || new Date().toISOString().slice(0, 10),
      call_time || new Date().toTimeString().slice(0, 5),
      parseInt(duration) || 0,
      plan_version || null,
      issue_id || null,
      issue_description || '',
      req.session.user.id
    );

    logAudit(req.session.user.id, 'CREATE_CALL', `Created support ticket #${ticket_no} for customer ID ${customer_id}`, req.ip);

    req.flash('success', `Call record created successfully (Ticket: ${ticket_no})`);
    res.redirect('/admin/calls');
  } catch (err) {
    req.flash('error', 'Error creating call record: ' + err.message);
    res.redirect('/admin/calls/add');
  }
});

// Edit Call Record (GET)
router.get('/calls/edit/:id', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const call = db.prepare("SELECT * FROM call_records WHERE id = ?").get(req.params.id);

  if (!call) {
    req.flash('error', 'Call record not found');
    return res.redirect('/admin/calls');
  }

  const customers = db.prepare("SELECT id, name, company, customer_code, plan_version FROM customers WHERE is_active = 1 ORDER BY name").all();
  const issues = db.prepare("SELECT id, category, sub_category, description FROM issues_master WHERE is_active = 1 ORDER BY category, sub_category").all();
  const employees = db.prepare("SELECT id, name, emp_code FROM employees WHERE is_active = 1 ORDER BY name").all();
  const plans = db.prepare("SELECT plan_name FROM plan_versions WHERE is_active = 1 ORDER BY plan_name").all();

  res.render('admin/call-form', { isEdit: true, call, customers, issues, employees, plans });
});

// Edit Call Record (POST)
router.post('/calls/edit/:id', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const { customer_id, employee_id, call_date, call_time, duration, plan_version, issue_id, issue_description, status, resolution_notes } = req.body;

  try {
    const existingCall = db.prepare("SELECT * FROM call_records WHERE id = ?").get(req.params.id);
    if (!existingCall) {
      req.flash('error', 'Call record not found');
      return res.redirect('/admin/calls');
    }

    let resolvedAt = existingCall.resolved_at;
    let resolvedBy = existingCall.resolved_by;

    if (status === 'resolved' && existingCall.status !== 'resolved') {
      resolvedAt = new Date().toISOString();
      resolvedBy = employee_id || req.session.user.employee_id || null;
    }

    db.prepare(`
      UPDATE call_records 
      SET customer_id = ?, employee_id = ?, call_date = ?, call_time = ?, duration = ?, 
          plan_version = ?, issue_id = ?, issue_description = ?, status = ?, 
          resolution_notes = ?, resolved_at = ?, resolved_by = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(
      customer_id,
      employee_id || null,
      call_date,
      call_time,
      parseInt(duration) || 0,
      plan_version || null,
      issue_id || null,
      issue_description || '',
      status || 'open',
      resolution_notes || '',
      resolvedAt,
      resolvedBy,
      req.params.id
    );

    // Record escalation transaction if status set to 'escalated'
    if (status === 'escalated') {
      const existingEsc = db.prepare("SELECT id FROM escalations WHERE call_record_id = ? AND status != 'resolved'").get(req.params.id);
      if (!existingEsc) {
        const adminEmp = db.prepare("SELECT id FROM employees WHERE user_id = ?").get(req.session.user.id);
        const escFrom = adminEmp ? adminEmp.id : null;
        db.prepare(`
          INSERT INTO escalations (call_record_id, escalated_from, reason, priority, status)
          VALUES (?, ?, ?, 'high', 'pending')
        `).run(
          req.params.id,
          escFrom,
          resolution_notes || issue_description || 'Escalated by Administrator via Call Edit'
        );
      }
    } else if (status === 'resolved' && existingCall.status === 'escalated') {
      db.prepare(`
        UPDATE escalations 
        SET status = 'resolved', resolved_at = datetime('now'), resolution_notes = ? 
        WHERE call_record_id = ? AND status != 'resolved'
      `).run(resolution_notes || 'Resolved by Administrator', req.params.id);
    }

    logAudit(req.session.user.id, 'EDIT_CALL', `Updated call record ticket #${existingCall.ticket_no}`, req.ip);

    req.flash('success', `Call record #${existingCall.ticket_no} updated successfully`);
    res.redirect('/admin/calls/view/' + req.params.id);
  } catch (err) {
    req.flash('error', 'Error updating call record: ' + err.message);
    res.redirect('/admin/calls/edit/' + req.params.id);
  }
});

// Direct Escalate Call (POST - ADMIN)
router.post('/calls/:id/escalate', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const { reason, priority, escalated_to } = req.body;

  try {
    const call = db.prepare("SELECT * FROM call_records WHERE id = ?").get(req.params.id);
    if (!call) {
      req.flash('error', 'Call record not found');
      return res.redirect('/admin/calls');
    }

    const adminEmp = db.prepare("SELECT id FROM employees WHERE user_id = ?").get(req.session.user.id);
    const escFrom = adminEmp ? adminEmp.id : null;
    const escTo = escalated_to ? parseInt(escalated_to) : null;
    const escStatus = escTo ? 'assigned' : 'pending';

    const escTx = db.transaction(() => {
      // 1. Insert escalation transaction
      db.prepare(`
        INSERT INTO escalations (call_record_id, escalated_from, escalated_to, reason, priority, status)
        VALUES (?, ?, ?, ?, ?, ?)
      `).run(
        req.params.id,
        escFrom,
        escTo,
        reason || 'Escalated for senior technical/management intervention',
        priority || 'high',
        escStatus
      );

      // 2. Update call record status to 'escalated'
      if (escTo) {
        db.prepare(`
          UPDATE call_records 
          SET status = 'escalated', employee_id = ?, updated_at = CURRENT_TIMESTAMP 
          WHERE id = ?
        `).run(escTo, req.params.id);

        db.prepare(`
          INSERT INTO call_allocations (call_record_id, allocated_to, allocated_by, status, notes)
          VALUES (?, ?, ?, 'assigned', ?)
        `).run(req.params.id, escTo, req.session.user.id, `Escalation allocated: ${reason || 'Priority escalation'}`);
      } else {
        db.prepare(`
          UPDATE call_records 
          SET status = 'escalated', updated_at = CURRENT_TIMESTAMP 
          WHERE id = ?
        `).run(req.params.id);
      }
    });

    escTx();

    logAudit(req.session.user.id, 'ESCALATE_CALL', `Admin escalated ticket #${call.ticket_no} (Priority: ${priority || 'high'})`, req.ip);

    req.flash('success', `Escalation transaction recorded for ticket #${call.ticket_no} successfully.`);
    res.redirect('/admin/escalations');
  } catch (err) {
    console.error('Admin escalation error:', err);
    req.flash('error', 'Error recording escalation: ' + err.message);
    res.redirect('/admin/calls/view/' + req.params.id);
  }
});

// DELETE Call Record (ADMIN ONLY)
router.post('/calls/:id/delete', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const call = db.prepare("SELECT * FROM call_records WHERE id = ?").get(req.params.id);

  if (!call) {
    req.flash('error', 'Call record not found');
    return res.redirect('/admin/calls');
  }

  try {
    const deleteTx = db.transaction(() => {
      // 1. Delete associated escalations
      db.prepare("DELETE FROM escalations WHERE call_record_id = ?").run(call.id);
      // 2. Delete associated allocations
      db.prepare("DELETE FROM call_allocations WHERE call_record_id = ?").run(call.id);
      // 3. Delete notifications
      db.prepare("DELETE FROM notifications WHERE call_record_id = ?").run(call.id);
      // 4. Delete the call record itself
      db.prepare("DELETE FROM call_records WHERE id = ?").run(call.id);
    });

    deleteTx();

    logAudit(req.session.user.id, 'DELETE_CALL_TRANSACTION', `Permanently deleted call transaction ticket #${call.ticket_no} (ID: ${call.id})`, req.ip);

    req.flash('success', `Call record transaction #${call.ticket_no} has been permanently deleted.`);
    res.redirect('/admin/calls');
  } catch (err) {
    console.error('Delete call transaction error:', err);
    req.flash('error', 'Error deleting call transaction: ' + err.message);
    res.redirect('/admin/calls');
  }
});

router.get('/calls/view/:id', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const call = db.prepare(`
    SELECT cr.*, c.name as customer_name, c.company, c.email as customer_email,
           c.mobile as customer_mobile, c.phone as customer_phone, c.customer_code,
           e.name as employee_name, e.emp_code,
           im.category, im.sub_category, im.description as issue_desc, im.priority as issue_priority,
           rb.name as resolved_by_name
    FROM call_records cr
    LEFT JOIN customers c ON cr.customer_id = c.id
    LEFT JOIN employees e ON cr.employee_id = e.id
    LEFT JOIN issues_master im ON cr.issue_id = im.id
    LEFT JOIN employees rb ON cr.resolved_by = rb.id
    WHERE cr.id = ?
  `).get(req.params.id);

  if (!call) {
    req.flash('error', 'Call record not found');
    return res.redirect('/admin/calls');
  }

  const allocations = db.prepare(`
    SELECT ca.*, e.name as employee_name, u.username as allocated_by_name
    FROM call_allocations ca
    LEFT JOIN employees e ON ca.allocated_to = e.id
    LEFT JOIN users u ON ca.allocated_by = u.id
    WHERE ca.call_record_id = ?
    ORDER BY ca.allocated_at DESC
  `).all(req.params.id);

  const escalations = db.prepare(`
    SELECT esc.*, ef.name as escalated_from_name, et.name as escalated_to_name
    FROM escalations esc
    LEFT JOIN employees ef ON esc.escalated_from = ef.id
    LEFT JOIN employees et ON esc.escalated_to = et.id
    WHERE esc.call_record_id = ?
    ORDER BY esc.escalated_at DESC
  `).all(req.params.id);

  const employees = db.prepare("SELECT id, name, emp_code FROM employees WHERE is_active = 1 ORDER BY name").all();

  res.render('admin/call-view', { call, allocations, escalations, employees });
});

router.post('/calls/:id/resolve', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const { resolution_notes, resolved_by } = req.body;

  try {
    let resolvedByEmpId = resolved_by || null;
    if (!resolvedByEmpId) {
      const emp = db.prepare("SELECT id FROM employees WHERE user_id = ?").get(req.session.user.id);
      resolvedByEmpId = emp ? emp.id : null;
    }

    db.prepare(`
      UPDATE call_records 
      SET status='resolved', resolution_notes=?, resolved_at=datetime('now'), resolved_by=?, updated_at=CURRENT_TIMESTAMP 
      WHERE id=?
    `).run(resolution_notes, resolvedByEmpId, req.params.id);

    // Fetch customer info and trigger notification
    const callRecord = db.prepare(`
      SELECT cr.ticket_no, cr.issue_description, c.name, c.email
      FROM call_records cr
      LEFT JOIN customers c ON cr.customer_id = c.id
      WHERE cr.id = ?
    `).get(req.params.id);

    if (callRecord && callRecord.email) {
      sendResolutionNotification(
        { name: callRecord.name, email: callRecord.email },
        callRecord.ticket_no,
        callRecord.issue_description || 'General Support',
        resolution_notes || 'Resolved'
      ).catch(e => console.error('Notification error:', e));
    }

    logAudit(req.session.user.id, 'RESOLVE_CALL', `Admin marked call #${callRecord?.ticket_no || req.params.id} as resolved`, req.ip);

    req.flash('success', 'Call resolved successfully and notification sent');
    res.redirect('/admin/calls/view/' + req.params.id);
  } catch (err) {
    req.flash('error', 'Error resolving call: ' + err.message);
    res.redirect('/admin/calls/view/' + req.params.id);
  }
});

// ═══════════════════════════════════════════════════
//  CALL ALLOCATIONS
// ═══════════════════════════════════════════════════
router.get('/allocations', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const openCalls = db.prepare(`
    SELECT cr.*, c.name as customer_name, c.company,
           im.category, im.sub_category, im.description as issue_desc
    FROM call_records cr
    LEFT JOIN customers c ON cr.customer_id = c.id
    LEFT JOIN issues_master im ON cr.issue_id = im.id
    WHERE cr.status = 'open' OR cr.employee_id IS NULL
    ORDER BY cr.created_at DESC
  `).all();

  const employees = db.prepare("SELECT id, name, emp_code, designation FROM employees WHERE is_active = 1 ORDER BY name").all();

  res.render('admin/allocations', { openCalls, unassignedCalls: openCalls, employees });
});

router.post('/allocations/assign', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const { call_id, employee_id } = req.body;

  try {
    const assignTx = db.transaction(() => {
      // Insert into call allocations history
      db.prepare(`
        INSERT INTO call_allocations (call_record_id, allocated_to, allocated_by)
        VALUES (?, ?, ?)
      `).run(call_id, employee_id, req.session.user.id);

      // Update call records table
      db.prepare(`
        UPDATE call_records 
        SET employee_id=?, status='assigned', updated_at=CURRENT_TIMESTAMP 
        WHERE id=?
      `).run(employee_id, call_id);
    });

    assignTx();

    const emp = db.prepare('SELECT name FROM employees WHERE id = ?').get(employee_id);
    logAudit(req.session.user.id, 'ALLOCATE_CALL', `Assigned call ID ${call_id} to employee ${emp ? emp.name : employee_id}`, req.ip);

    req.flash('success', 'Call assigned successfully');
    res.redirect('/admin/allocations');
  } catch (err) {
    req.flash('error', 'Error assigning call: ' + err.message);
    res.redirect('/admin/allocations');
  }
});

// DELETE Allocation Transaction (ADMIN ONLY)
router.post('/allocations/:id/delete', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const alloc = db.prepare("SELECT * FROM call_allocations WHERE id = ?").get(req.params.id);

  if (!alloc) {
    req.flash('error', 'Allocation record not found');
    return res.redirect('/admin/allocations');
  }

  try {
    db.prepare("DELETE FROM call_allocations WHERE id = ?").run(alloc.id);
    logAudit(req.session.user.id, 'DELETE_ALLOCATION_TRANSACTION', `Deleted allocation transaction #${alloc.id}`, req.ip);
    req.flash('success', 'Call allocation transaction deleted successfully.');
    res.redirect('back');
  } catch (err) {
    req.flash('error', 'Error deleting allocation: ' + err.message);
    res.redirect('back');
  }
});

// ═══════════════════════════════════════════════════
//  ESCALATIONS
// ═══════════════════════════════════════════════════
router.get('/escalations', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const escalations = db.prepare(`
    SELECT esc.*, cr.ticket_no, cr.issue_description, cr.status as call_status,
           c.name as customer_name, c.company,
           ef.name as escalated_from_name,
           et.name as escalated_to_name
    FROM escalations esc
    LEFT JOIN call_records cr ON esc.call_record_id = cr.id
    LEFT JOIN customers c ON cr.customer_id = c.id
    LEFT JOIN employees ef ON esc.escalated_from = ef.id
    LEFT JOIN employees et ON esc.escalated_to = et.id
    ORDER BY esc.escalated_at DESC
  `).all();

  const employees = db.prepare("SELECT id, name, emp_code FROM employees WHERE is_active = 1 ORDER BY name").all();
  const openCalls = db.prepare(`
    SELECT cr.id, cr.ticket_no, cr.issue_description, cr.status, c.name as customer_name
    FROM call_records cr
    LEFT JOIN customers c ON cr.customer_id = c.id
    WHERE cr.status IN ('open', 'assigned', 'in_progress')
    ORDER BY cr.id DESC
  `).all();

  res.render('admin/escalations', { escalations, employees, openCalls });
});

router.post('/escalations/:id/assign', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const { escalated_to } = req.body;

  try {
    const escAssignTx = db.transaction(() => {
      db.prepare(`
        UPDATE escalations 
        SET escalated_to=?, status='assigned' 
        WHERE id=?
      `).run(escalated_to, req.params.id);

      const esc = db.prepare("SELECT call_record_id FROM escalations WHERE id = ?").get(req.params.id);
      if (esc && esc.call_record_id) {
        db.prepare(`
          UPDATE call_records 
          SET employee_id=?, updated_at=CURRENT_TIMESTAMP 
          WHERE id=?
        `).run(escalated_to, esc.call_record_id);
      }
    });

    escAssignTx();

    logAudit(req.session.user.id, 'ASSIGN_ESCALATION', `Assigned escalation #${req.params.id} to employee ID ${escalated_to}`, req.ip);

    req.flash('success', 'Escalation assigned successfully');
    res.redirect('/admin/escalations');
  } catch (err) {
    req.flash('error', 'Error assigning escalation: ' + err.message);
    res.redirect('/admin/escalations');
  }
});

// DELETE Escalation Transaction (ADMIN ONLY)
router.post('/escalations/:id/delete', isAuthenticated, isAdmin, (req, res) => {
  const db = getDb();
  const esc = db.prepare("SELECT * FROM escalations WHERE id = ?").get(req.params.id);

  if (!esc) {
    req.flash('error', 'Escalation not found');
    return res.redirect('/admin/escalations');
  }

  try {
    const delEscTx = db.transaction(() => {
      // Revert linked call record status from 'escalated' to 'assigned' if it is still escalated
      if (esc.call_record_id) {
        db.prepare(`
          UPDATE call_records 
          SET status = 'assigned', updated_at = CURRENT_TIMESTAMP
          WHERE id = ? AND status = 'escalated'
        `).run(esc.call_record_id);
      }
      // Delete escalation transaction
      db.prepare("DELETE FROM escalations WHERE id = ?").run(esc.id);
    });

    delEscTx();

    logAudit(req.session.user.id, 'DELETE_ESCALATION_TRANSACTION', `Deleted escalation transaction #${esc.id} linked to call ID ${esc.call_record_id}`, req.ip);

    req.flash('success', 'Escalation transaction deleted and ticket status restored.');
    res.redirect('/admin/escalations');
  } catch (err) {
    req.flash('error', 'Error deleting escalation: ' + err.message);
    res.redirect('/admin/escalations');
  }
});

module.exports = router;
