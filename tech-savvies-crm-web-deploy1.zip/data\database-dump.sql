-- ==========================================
-- Tech Savvies ERP Support CRM Database Dump
-- Export Date: 2026-11-24T11:37:50.750Z
-- Engine: SQLite3 (Compatible with PostgreSQL / MySQL)
-- ==========================================

PRAGMA foreign_keys = OFF;

-- Table structure for: users
DROP TABLE IF EXISTS users;
CREATE TABLE users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('admin','user','employee')),
      status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected','blocked')),
      reset_token TEXT,
      reset_token_expires DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

-- Dumping data for table: users (4 records)
INSERT INTO users (id, username, email, password, role, status, reset_token, reset_token_expires, created_at, updated_at) VALUES (1, 'ADMIN', 'admin@techsavvies.com', '$2a$10$Z/jglzECGjvNiGk5Pwb1q.xAok7sJehVUMcNwsc5JyDwjBtAJcotS', 'admin', 'approved', NULL, NULL, '2026-11-23 15:55:05', '2026-11-23 15:56:21');
INSERT INTO users (id, username, email, password, role, status, reset_token, reset_token_expires, created_at, updated_at) VALUES (3, 'TS@123456', 'support.techsavvies@gmail.com', '$2a$10$qNaK31JLPqM5GCybjEUEhefFIJVhZCi4gdMxFrHwtsKN3YdlitAW.', 'employee', 'approved', NULL, NULL, '2026-11-23 16:10:05', '2026-11-23 18:02:47');
INSERT INTO users (id, username, email, password, role, status, reset_token, reset_token_expires, created_at, updated_at) VALUES (4, 'Test', 'info.techsavvies@gmail.com', '$2a$10$oGc1JI3eLdf31MN.Aag84O26KF.vJ4VoVK7UaN/ij4ZmzMNS8r0ve', 'employee', 'rejected', NULL, NULL, '2026-11-23 16:20:41', '2026-11-23 18:02:13');
INSERT INTO users (id, username, email, password, role, status, reset_token, reset_token_expires, created_at, updated_at) VALUES (5, 'ravi_support', 'ravi@techsavvies.com', '$2a$10$PZoEqVeZrs4dvmVh4ImE3e04R99AH.sU/b0tbk76vDxjrbdTMBKXC', 'employee', 'rejected', NULL, NULL, '2026-11-23 17:02:43', '2026-11-23 18:02:09');

-- Table structure for: plan_versions
DROP TABLE IF EXISTS plan_versions;
CREATE TABLE plan_versions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      plan_code TEXT UNIQUE NOT NULL,
      plan_name TEXT NOT NULL,
      description TEXT,
      version_no TEXT,
      is_active INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

-- Dumping data for table: plan_versions (5 records)
INSERT INTO plan_versions (id, plan_code, plan_name, description, version_no, is_active, created_at, updated_at) VALUES (1, 'PLN001', 'Alignbooks Basic', 'Entry level package for small business operations', 'v1.0', 1, '2026-11-23 16:45:21', '2026-11-23 16:49:52');
INSERT INTO plan_versions (id, plan_code, plan_name, description, version_no, is_active, created_at, updated_at) VALUES (2, 'PLN002', 'Alignbooks Premium', 'Standard multi-user commercial ERP solution', 'v2.4', 1, '2026-11-23 16:45:21', '2026-11-23 16:49:35');
INSERT INTO plan_versions (id, plan_code, plan_name, description, version_no, is_active, created_at, updated_at) VALUES (3, 'PLN003', 'Alignbooks Enterprise', 'Full-fledged enterprise suite with inventory, manufacturing and HR', 'v3.5', 1, '2026-11-23 16:45:21', '2026-11-23 16:50:41');
INSERT INTO plan_versions (id, plan_code, plan_name, description, version_no, is_active, created_at, updated_at) VALUES (4, 'PLN004', 'Alignbooks Ultimate', 'Cloud multi-branch real-time sync ERP solution', 'v4.0', 1, '2026-11-23 16:45:21', '2026-11-23 16:49:01');
INSERT INTO plan_versions (id, plan_code, plan_name, description, version_no, is_active, created_at, updated_at) VALUES (5, 'PLN0005', 'Alignbooks ERP', '', '1', 1, '2026-11-23 16:50:20', '2026-11-23 16:50:20');

-- Table structure for: employees
DROP TABLE IF EXISTS employees;
CREATE TABLE employees (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER UNIQUE,
      emp_code TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT,
      designation TEXT,
      department TEXT,
      address TEXT,
      profile_pic TEXT,
      is_active INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    );

-- Dumping data for table: employees (4 records)
INSERT INTO employees (id, user_id, emp_code, name, email, phone, designation, department, address, profile_pic, is_active, created_at, updated_at) VALUES (1, 3, 'EMP0001', 'SREEPARVATHY', 'support.techsavvies@gmail.com', NULL, NULL, NULL, NULL, NULL, 1, '2026-11-23 16:10:05', '2026-11-23 16:10:05');
INSERT INTO employees (id, user_id, emp_code, name, email, phone, designation, department, address, profile_pic, is_active, created_at, updated_at) VALUES (2, 4, 'EMP0002', 'Test Employee', 'info.techsavvies@gmail.com', '7902700123', NULL, NULL, NULL, NULL, 1, '2026-11-23 16:20:41', '2026-11-23 16:20:41');
INSERT INTO employees (id, user_id, emp_code, name, email, phone, designation, department, address, profile_pic, is_active, created_at, updated_at) VALUES (3, 1, 'EMP0003', 'ADMIN', 'admin@techsavvies.com', '', 'Administrator', 'Technical Support', '', NULL, 1, '2026-11-23 16:45:57', '2026-11-23 16:45:57');
INSERT INTO employees (id, user_id, emp_code, name, email, phone, designation, department, address, profile_pic, is_active, created_at, updated_at) VALUES (4, 5, 'EMP0004', 'ravi_support', 'ravi@techsavvies.com', '', 'Support Engineer', 'Technical Support', '', NULL, 1, '2026-11-23 17:02:58', '2026-11-23 17:02:58');

-- Table structure for: customers
DROP TABLE IF EXISTS customers;
CREATE TABLE customers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      customer_code TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      company TEXT,
      email TEXT,
      mobile TEXT NOT NULL,
      phone TEXT,
      plan_version TEXT,
      address TEXT,
      city TEXT,
      state TEXT,
      pincode TEXT,
      gst_no TEXT,
      is_active INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    , password TEXT, portal_username TEXT, portal_enabled INTEGER DEFAULT 1);

-- Dumping data for table: customers (4 records)
INSERT INTO customers (id, customer_code, name, company, email, mobile, phone, plan_version, address, city, state, pincode, gst_no, is_active, created_at, updated_at, password, portal_username, portal_enabled) VALUES (1, 'CUS0001', 'ABC', 'BBB', NULL, '1234567890', NULL, 'Alignbooks Basic', NULL, NULL, NULL, NULL, NULL, 1, '2026-11-23 16:07:21', '2026-11-23 21:06:46', '$2a$10$N5ZvAY6dkvWGYH71AzT8NOrKq/N92Vw7bLNH4laCpgY27KG/1RksW', NULL, 1);
INSERT INTO customers (id, customer_code, name, company, email, mobile, phone, plan_version, address, city, state, pincode, gst_no, is_active, created_at, updated_at, password, portal_username, portal_enabled) VALUES (2, 'CUS0002', 'Test ERP Client', 'Savvy Technologies', 'client@techsavvies.com', '9876543210', NULL, 'ERP Enterprise Suite', NULL, NULL, NULL, NULL, NULL, 1, '2026-11-23 16:45:56', '2026-11-23 16:45:56', NULL, NULL, 1);
INSERT INTO customers (id, customer_code, name, company, email, mobile, phone, plan_version, address, city, state, pincode, gst_no, is_active, created_at, updated_at, password, portal_username, portal_enabled) VALUES (3, 'CUS0003', 'Apex Retailers Ltd', 'Apex Retailers Pvt Ltd', 'support@apexretailers.com', '9845012345', NULL, 'ERP Enterprise', NULL, NULL, NULL, NULL, NULL, 1, '2026-11-23 20:15:20', '2026-11-23 20:15:20', '$2a$10$QuLAncFR1MxskzKG4zx3T.49tAziHzUtwQoDoOhKCYavyTmOAaYJ6', NULL, 1);
INSERT INTO customers (id, customer_code, name, company, email, mobile, phone, plan_version, address, city, state, pincode, gst_no, is_active, created_at, updated_at, password, portal_username, portal_enabled) VALUES (4, 'CUS0004', 'Skyline Logistics', 'Skyline Logistics Global', 'ops@skylinelogistics.com', '9822011223', '', 'ERP Enterprise', '', 'Pune', 'Maharashtra', '', '', 1, '2026-11-24 11:28:30', '2026-11-24 11:28:30', NULL, NULL, 1);

-- Table structure for: issues_master
DROP TABLE IF EXISTS issues_master;
CREATE TABLE issues_master (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      issue_code TEXT UNIQUE NOT NULL,
      category TEXT NOT NULL,
      sub_category TEXT,
      description TEXT NOT NULL,
      priority TEXT DEFAULT 'medium' CHECK(priority IN ('low','medium','high','critical')),
      estimated_time INTEGER DEFAULT 30,
      is_active INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

-- Dumping data for table: issues_master (12 records)
INSERT INTO issues_master (id, issue_code, category, sub_category, description, priority, estimated_time, is_active, created_at) VALUES (1, 'ISS001', 'ERP Module', 'Login', 'Unable to login to ERP system', 'high', 15, 1, '2026-11-23 15:55:05');
INSERT INTO issues_master (id, issue_code, category, sub_category, description, priority, estimated_time, is_active, created_at) VALUES (2, 'ISS002', 'ERP Module', 'Reports', 'Reports not generating correctly', 'medium', 30, 1, '2026-11-23 15:55:05');
INSERT INTO issues_master (id, issue_code, category, sub_category, description, priority, estimated_time, is_active, created_at) VALUES (3, 'ISS003', 'ERP Module', 'Invoice', 'Invoice printing error', 'medium', 20, 1, '2026-11-23 15:55:05');
INSERT INTO issues_master (id, issue_code, category, sub_category, description, priority, estimated_time, is_active, created_at) VALUES (4, 'ISS004', 'ERP Module', 'Inventory', 'Stock mismatch in inventory module', 'high', 45, 1, '2026-11-23 15:55:05');
INSERT INTO issues_master (id, issue_code, category, sub_category, description, priority, estimated_time, is_active, created_at) VALUES (5, 'ISS005', 'ERP Module', 'Payroll', 'Salary calculation error', 'critical', 60, 1, '2026-11-23 15:55:05');
INSERT INTO issues_master (id, issue_code, category, sub_category, description, priority, estimated_time, is_active, created_at) VALUES (6, 'ISS006', 'Technical', 'Server', 'Server connectivity issues', 'critical', 30, 1, '2026-11-23 15:55:05');
INSERT INTO issues_master (id, issue_code, category, sub_category, description, priority, estimated_time, is_active, created_at) VALUES (7, 'ISS007', 'Technical', 'Database', 'Database backup failure', 'high', 45, 1, '2026-11-23 15:55:05');
INSERT INTO issues_master (id, issue_code, category, sub_category, description, priority, estimated_time, is_active, created_at) VALUES (8, 'ISS008', 'Technical', 'Network', 'Network connectivity problem', 'high', 20, 1, '2026-11-23 15:55:05');
INSERT INTO issues_master (id, issue_code, category, sub_category, description, priority, estimated_time, is_active, created_at) VALUES (9, 'ISS009', 'Installation', 'Setup', 'Software installation issues', 'medium', 60, 1, '2026-11-23 15:55:05');
INSERT INTO issues_master (id, issue_code, category, sub_category, description, priority, estimated_time, is_active, created_at) VALUES (10, 'ISS010', 'General', 'Training', 'User training required', 'low', 120, 1, '2026-11-23 15:55:05');
INSERT INTO issues_master (id, issue_code, category, sub_category, description, priority, estimated_time, is_active, created_at) VALUES (11, 'ISS011', 'ERP Module', 'GST', 'GST filing/return errors', 'high', 30, 1, '2026-11-23 15:55:05');
INSERT INTO issues_master (id, issue_code, category, sub_category, description, priority, estimated_time, is_active, created_at) VALUES (12, 'ISS012', 'ERP Module', 'Purchase', 'Purchase order processing error', 'medium', 25, 1, '2026-11-23 15:55:05');

-- Table structure for: call_records
DROP TABLE IF EXISTS call_records;
CREATE TABLE call_records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ticket_no TEXT UNIQUE NOT NULL,
      customer_id INTEGER NOT NULL,
      employee_id INTEGER,
      call_date DATE NOT NULL,
      call_time TIME NOT NULL,
      duration INTEGER DEFAULT 0,
      plan_version TEXT,
      issue_id INTEGER,
      issue_description TEXT,
      status TEXT DEFAULT 'open' CHECK(status IN ('open','assigned','in_progress','resolved','escalated','closed')),
      resolution_notes TEXT,
      resolved_at DATETIME,
      resolved_by INTEGER,
      created_by INTEGER,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, source TEXT DEFAULT 'call',
      FOREIGN KEY (customer_id) REFERENCES customers(id),
      FOREIGN KEY (employee_id) REFERENCES employees(id),
      FOREIGN KEY (issue_id) REFERENCES issues_master(id),
      FOREIGN KEY (resolved_by) REFERENCES employees(id),
      FOREIGN KEY (created_by) REFERENCES users(id)
    );

-- Dumping data for table: call_records (1 records)
INSERT INTO call_records (id, ticket_no, customer_id, employee_id, call_date, call_time, duration, plan_version, issue_id, issue_description, status, resolution_notes, resolved_at, resolved_by, created_by, created_at, updated_at, source) VALUES (8, 'TKT202611230001', 1, 1, '2026-11-23', '02:36', 0, 'Alignbooks Basic', 4, 'Stock mismatch in inventory module:', 'resolved', 'a', '2026-11-24 11:31:53', 1, NULL, '2026-11-23 21:06:56', '2026-11-24 11:31:53', 'customer_portal');

-- Table structure for: call_allocations
DROP TABLE IF EXISTS call_allocations;
CREATE TABLE call_allocations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      call_record_id INTEGER NOT NULL,
      allocated_to INTEGER NOT NULL,
      allocated_by INTEGER NOT NULL,
      allocated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      status TEXT DEFAULT 'assigned' CHECK(status IN ('assigned','accepted','in_progress','completed','reassigned')),
      notes TEXT,
      FOREIGN KEY (call_record_id) REFERENCES call_records(id),
      FOREIGN KEY (allocated_to) REFERENCES employees(id),
      FOREIGN KEY (allocated_by) REFERENCES users(id)
    );

-- Dumping data for table: call_allocations (1 records)
INSERT INTO call_allocations (id, call_record_id, allocated_to, allocated_by, allocated_at, status, notes) VALUES (8, 8, 1, 1, '2026-11-23 21:08:19', 'assigned', NULL);

-- Table structure for: escalations
DROP TABLE IF EXISTS escalations;
CREATE TABLE escalations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      call_record_id INTEGER NOT NULL,
      escalated_from INTEGER NOT NULL,
      escalated_to INTEGER,
      reason TEXT NOT NULL,
      priority TEXT DEFAULT 'high' CHECK(priority IN ('medium','high','critical')),
      status TEXT DEFAULT 'pending' CHECK(status IN ('pending','assigned','resolved')),
      resolution_notes TEXT,
      escalated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      resolved_at DATETIME,
      FOREIGN KEY (call_record_id) REFERENCES call_records(id),
      FOREIGN KEY (escalated_from) REFERENCES employees(id),
      FOREIGN KEY (escalated_to) REFERENCES employees(id)
    );

-- Table structure for: notifications
DROP TABLE IF EXISTS notifications;
CREATE TABLE notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      call_record_id INTEGER,
      customer_id INTEGER,
      type TEXT NOT NULL CHECK(type IN ('sms','email')),
      recipient TEXT NOT NULL,
      subject TEXT,
      message TEXT NOT NULL,
      status TEXT DEFAULT 'pending' CHECK(status IN ('pending','sent','failed')),
      sent_at DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (call_record_id) REFERENCES call_records(id),
      FOREIGN KEY (customer_id) REFERENCES customers(id)
    );

-- Table structure for: activity_log
DROP TABLE IF EXISTS activity_log;
CREATE TABLE activity_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      action TEXT NOT NULL,
      details TEXT,
      ip_address TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

-- Dumping data for table: activity_log (102 records)
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (1, 1, 'USER_LOGIN', 'User ADMIN logged in successfully', '::1', '2026-11-23 16:45:40');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (2, 1, 'USER_LOGIN', 'User ADMIN logged in successfully', '::1', '2026-11-23 16:45:56');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (3, 1, 'CREATE_CUSTOMER', 'Created customer CUS0002 - Test ERP Client', '::1', '2026-11-23 16:45:56');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (4, 1, 'CREATE_CALL', 'Created support ticket #TKT202611230002 for customer ID 1', '::1', '2026-11-23 16:45:56');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (5, 1, 'ESCALATE_CALL', 'Escalated ticket #TKT202611230001 - Priority: critical. Reason: Unable to connect to database replica directly, needs senior DB administrator', '::1', '2026-11-23 16:45:57');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (6, 1, 'USER_LOGIN', 'User ADMIN logged in successfully', '::1', '2026-11-23 16:46:09');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (7, 1, 'EDIT_CALL', 'Updated call record ticket #TKT202611230001', '::1', '2026-11-23 16:46:09');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (8, 1, 'USER_LOGIN', 'User ADMIN logged in successfully', '::1', '2026-11-23 16:48:23');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (9, 1, 'UPDATE_PLAN', 'Updated plan version #4 (Alignbooks Ultimate)', '::1', '2026-11-23 16:49:01');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (10, 1, 'UPDATE_PLAN', 'Updated plan version #3 (ALignbooks Enterprise Suite)', '::1', '2026-11-23 16:49:14');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (11, 1, 'UPDATE_PLAN', 'Updated plan version #2 (Alignbooks Premium)', '::1', '2026-11-23 16:49:35');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (12, 1, 'UPDATE_PLAN', 'Updated plan version #1 (Alignbooks Basic)', '::1', '2026-11-23 16:49:52');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (13, 1, 'CREATE_PLAN', 'Created plan PLN0005 - Alignbooks ERP', '::1', '2026-11-23 16:50:20');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (14, 1, 'UPDATE_PLAN', 'Updated plan version #3 (ALignbooks Enterprise )', '::1', '2026-11-23 16:50:30');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (15, 1, 'UPDATE_PLAN', 'Updated plan version #3 (Alignbooks Enterprise)', '::1', '2026-11-23 16:50:41');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (16, 1, 'ASSIGN_ESCALATION', 'Assigned escalation #1 to employee ID 3', '::1', '2026-11-23 16:51:00');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (17, 1, 'RESOLVE_CALL', 'Admin marked call #TKT202611230001 as resolved', '::1', '2026-11-23 16:51:17');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (18, 1, 'ALLOCATE_CALL', 'Assigned call ID 2 to employee SREEPARVATHY', '::1', '2026-11-23 16:52:10');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (19, 1, 'EDIT_CALL', 'Updated call record ticket #TKT202611230002', '::1', '2026-11-23 16:52:41');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (20, 1, 'RESOLVE_CALL', 'Admin marked call #TKT202611230002 as resolved', '::1', '2026-11-23 16:53:11');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (21, 5, 'USER_REGISTER', 'New user registration for ravi_support (Pending approval)', '::1', '2026-11-23 17:02:43');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (22, 1, 'USER_LOGIN', 'User ADMIN logged in successfully', '::1', '2026-11-23 17:02:43');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (23, 1, 'USER_LOGIN', 'User ADMIN logged in successfully', '::1', '2026-11-23 17:02:58');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (24, 1, 'MAP_USER_EMPLOYEE', 'Mapped user ravi_support to new employee EMP0004', '::1', '2026-11-23 17:02:58');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (25, 1, 'USER_LOGIN', 'User ADMIN logged in successfully', '::1', '2026-11-23 17:03:14');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (26, 1, 'DELETE_CALL_TRANSACTION', 'Permanently deleted call transaction ticket #TKT202611230001 (ID: 1)', '::1', '2026-11-23 17:03:14');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (27, 1, 'USER_LOGIN', 'User ADMIN logged in successfully', '::1', '2026-11-23 17:03:58');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (28, 1, 'USER_LOGOUT', 'User ADMIN logged out', '::1', '2026-11-23 17:05:09');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (29, 3, 'USER_LOGIN', 'User TS@123456 logged in successfully', '::1', '2026-11-23 17:05:38');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (30, 3, 'USER_LOGIN', 'User TS@123456 logged in successfully', '::1', '2026-11-23 17:11:14');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (31, 5, 'USER_LOGIN', 'User ravi_support logged in successfully', '::1', '2026-11-23 17:11:29');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (32, 5, 'SELF_RECORD_CALL', 'Employee ravi_support (EMP0004) self-recorded ticket #TKT202611230003 (Status: resolved)', '::1', '2026-11-23 17:11:30');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (33, 3, 'USER_LOGOUT', 'User TS@123456 logged out', '::1', '2026-11-23 17:12:17');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (34, 5, 'USER_LOGIN', 'User ravi_support logged in successfully', '::1', '2026-11-23 17:12:33');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (35, 5, 'USER_LOGOUT', 'User ravi_support logged out', '::1', '2026-11-23 17:13:20');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (36, 3, 'USER_LOGIN', 'User TS@123456 logged in successfully', '::1', '2026-11-23 18:01:03');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (37, 3, 'USER_LOGOUT', 'User TS@123456 logged out', '::1', '2026-11-23 18:01:32');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (38, 1, 'USER_LOGIN', 'User ADMIN logged in successfully', '::1', '2026-11-23 18:01:42');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (39, 1, 'REJECT_USER', 'Rejected user registration for ravi_support', '::1', '2026-11-23 18:02:09');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (40, 1, 'REJECT_USER', 'Rejected user registration for Test', '::1', '2026-11-23 18:02:13');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (41, 1, 'REJECT_USER', 'Rejected user registration for TS@123456', '::1', '2026-11-23 18:02:17');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (42, 1, 'BLOCK_USER', 'Blocked user TS@123456', '::1', '2026-11-23 18:02:44');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (43, 1, 'REJECT_USER', 'Rejected user registration for TS@123456', '::1', '2026-11-23 18:02:46');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (44, 1, 'APPROVE_USER', 'Approved user registration for TS@123456', '::1', '2026-11-23 18:02:47');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (45, 1, 'USER_LOGOUT', 'User ADMIN logged out', '::1', '2026-11-23 18:03:15');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (46, 3, 'USER_LOGIN', 'User TS@123456 logged in successfully', '::1', '2026-11-23 18:16:00');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (47, 3, 'USER_LOGOUT', 'User TS@123456 logged out', '::1', '2026-11-23 18:16:57');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (48, NULL, 'CUSTOMER_COMPLAINT_REGISTERED', 'Customer Apex Retailers Ltd (9845012345) registered complaint #TKT202611230004. Automatically logged into Call Records.', '::1', '2026-11-23 20:15:20');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (49, NULL, 'CUSTOMER_LOGIN', 'Customer Apex Retailers Ltd (CUS0003) logged into portal', '::1', '2026-11-23 20:15:53');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (50, 1, 'USER_LOGIN', 'User ADMIN logged in successfully', '::1', '2026-11-23 20:16:14');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (51, 1, 'USER_LOGIN', 'User ADMIN logged in successfully', '::1', '2026-11-23 20:17:07');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (52, 1, 'USER_LOGIN', 'User ADMIN logged in successfully', '::1', '2026-11-23 20:18:05');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (53, 1, 'RESOLVE_CALL', 'Admin marked call #TKT202611230004 as resolved', '::1', '2026-11-23 20:18:05');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (54, NULL, 'CUSTOMER_COMPLAINT_REGISTERED', 'Customer Test Name (1234567890) registered complaint #TKT202611230005. Automatically logged into Call Records.', '::1', '2026-11-23 20:21:59');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (55, 3, 'USER_LOGIN', 'User TS@123456 logged in successfully', '::1', '2026-11-23 20:33:10');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (56, 3, 'USER_LOGOUT', 'User TS@123456 logged out', '::1', '2026-11-23 20:33:48');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (57, 1, 'USER_LOGIN', 'User ADMIN logged in successfully', '::1', '2026-11-23 20:33:54');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (58, 1, 'USER_LOGOUT', 'User ADMIN logged out', '::1', '2026-11-23 20:36:00');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (59, NULL, 'CUSTOMER_COMPLAINT_REGISTERED', 'Customer Test Name (1234567890) registered complaint #TKT202611230006. Automatically logged into Call Records.', '::1', '2026-11-23 20:36:16');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (60, 1, 'USER_LOGIN', 'User ADMIN logged in successfully', '::1', '2026-11-23 20:37:48');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (61, 1, 'USER_LOGIN', 'User ADMIN logged in successfully', '::1', '2026-11-23 20:46:02');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (62, NULL, 'CUSTOMER_COMPLAINT_REGISTERED', 'Customer Test Name (1234567890) registered complaint #TKT202611230007. Automatically logged into Call Records.', '::1', '2026-11-23 20:46:51');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (63, 1, 'ALLOCATE_CALL', 'Assigned call ID 7 to employee SREEPARVATHY', '::1', '2026-11-23 20:47:20');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (64, 1, 'RESOLVE_CALL', 'Admin marked call #TKT202611230007 as resolved', '::1', '2026-11-23 20:48:59');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (65, 1, 'ALLOCATE_CALL', 'Assigned call ID 6 to employee ADMIN', '::1', '2026-11-23 20:50:11');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (66, 1, 'USER_LOGOUT', 'User ADMIN logged out', '::1', '2026-11-23 20:57:21');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (67, 1, 'USER_LOGIN', 'User ADMIN logged in successfully', '::1', '2026-11-23 21:03:46');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (68, 1, 'ALLOCATE_CALL', 'Assigned call ID 5 to employee Test Employee', '::1', '2026-11-23 21:05:14');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (69, 1, 'ESCALATE_CALL', 'Admin escalated ticket #TKT202611230006 (Priority: critical)', '::1', '2026-11-23 21:05:25');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (70, 1, 'RESOLVE_CALL', 'Admin marked call #TKT202611230006 as resolved', '::1', '2026-11-23 21:05:39');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (71, 1, 'DELETE_ESCALATION_TRANSACTION', 'Deleted escalation transaction #3 linked to call ID 6', '::1', '2026-11-23 21:05:48');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (72, 1, 'DELETE_CALL_TRANSACTION', 'Permanently deleted call transaction ticket #TKT202611230007 (ID: 7)', '::1', '2026-11-23 21:06:05');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (73, 1, 'DELETE_CALL_TRANSACTION', 'Permanently deleted call transaction ticket #TKT202611230006 (ID: 6)', '::1', '2026-11-23 21:06:07');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (74, 1, 'DELETE_CALL_TRANSACTION', 'Permanently deleted call transaction ticket #TKT202611230005 (ID: 5)', '::1', '2026-11-23 21:06:09');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (75, 1, 'DELETE_CALL_TRANSACTION', 'Permanently deleted call transaction ticket #TKT202611230004 (ID: 4)', '::1', '2026-11-23 21:06:11');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (76, 1, 'DELETE_CALL_TRANSACTION', 'Permanently deleted call transaction ticket #TKT202611230003 (ID: 3)', '::1', '2026-11-23 21:06:12');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (77, 1, 'DELETE_CALL_TRANSACTION', 'Permanently deleted call transaction ticket #TKT202611230002 (ID: 2)', '::1', '2026-11-23 21:06:14');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (78, 1, 'USER_LOGOUT', 'User ADMIN logged out', '::1', '2026-11-23 21:06:24');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (79, NULL, 'CUSTOMER_REGISTER', 'New customer registered: ABC (CUS0001)', '::1', '2026-11-23 21:06:46');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (80, NULL, 'CUSTOMER_COMPLAINT_REGISTERED', 'Customer ABC (1234567890) registered complaint #TKT202611230001. Automatically logged into Call Records.', '::1', '2026-11-23 21:06:56');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (81, 1, 'USER_LOGIN', 'User ADMIN logged in successfully', '::1', '2026-11-23 21:07:59');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (82, 1, 'ALLOCATE_CALL', 'Assigned call ID 8 to employee SREEPARVATHY', '::1', '2026-11-23 21:08:19');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (83, 1, 'USER_LOGOUT', 'User ADMIN logged out', '::1', '2026-11-23 21:08:25');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (84, 3, 'USER_LOGIN', 'User TS@123456 logged in successfully', '::1', '2026-11-23 21:08:43');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (85, 3, 'USER_LOGOUT', 'User TS@123456 logged out', '::1', '2026-11-23 21:08:55');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (86, NULL, 'CUSTOMER_LOGIN', 'Customer ABC (CUS0001) logged into portal', '::1', '2026-11-23 21:09:14');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (87, 1, 'USER_LOGIN', 'User ADMIN logged in successfully', '::1', '2026-11-24 11:12:45');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (88, 1, 'USER_LOGOUT', 'User ADMIN logged out', '::1', '2026-11-24 11:14:00');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (89, 1, 'USER_LOGIN', 'User ADMIN logged in successfully', '::1', '2026-11-24 11:17:00');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (90, 1, 'USER_LOGOUT', 'User ADMIN logged out', '::1', '2026-11-24 11:22:42');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (91, 3, 'USER_LOGIN', 'User TS@123456 logged in successfully', '::1', '2026-11-24 11:22:47');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (92, 1, 'USER_LOGIN', 'User ADMIN logged in successfully', '::1', '2026-11-24 11:26:12');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (93, 1, 'USER_LOGIN', 'User ADMIN logged in successfully', '::1', '2026-11-24 11:28:10');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (94, 1, 'USER_LOGIN', 'User ADMIN logged in successfully', '::1', '2026-11-24 11:28:30');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (95, 1, 'CREATE_CUSTOMER', 'Employee ADMIN created customer CUS0004 - Skyline Logistics', '::1', '2026-11-24 11:28:30');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (96, 3, 'USER_LOGIN', 'User TS@123456 logged in successfully', '::1', '2026-11-24 11:29:34');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (97, 3, 'USER_LOGOUT', 'User TS@123456 logged out', '::1', '2026-11-24 11:30:03');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (98, NULL, 'CUSTOMER_LOGIN', 'Customer ABC (CUS0001) logged into portal', '::1', '2026-11-24 11:30:18');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (99, 3, 'USER_LOGIN', 'User TS@123456 logged in successfully', '::1', '2026-11-24 11:31:19');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (100, 3, 'RESOLVE_CALL', 'Resolved ticket #TKT202611230001', '::1', '2026-11-24 11:31:53');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (101, 3, 'USER_LOGOUT', 'User TS@123456 logged out', '::1', '2026-11-24 11:32:11');
INSERT INTO activity_log (id, user_id, action, details, ip_address, created_at) VALUES (102, NULL, 'CUSTOMER_LOGIN', 'Customer ABC (CUS0001) logged into portal', '::1', '2026-11-24 11:32:19');

-- Table structure for: change_requests
DROP TABLE IF EXISTS change_requests;
CREATE TABLE change_requests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      request_type TEXT NOT NULL CHECK(request_type IN ('username','password','both')),
      requested_username TEXT,
      requested_password TEXT,
      reason TEXT,
      status TEXT DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),
      admin_notes TEXT,
      reviewed_by INTEGER,
      reviewed_at DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id),
      FOREIGN KEY (reviewed_by) REFERENCES users(id)
    );

PRAGMA foreign_keys = ON;
