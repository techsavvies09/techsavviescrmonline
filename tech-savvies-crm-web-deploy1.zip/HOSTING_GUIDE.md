# Tech Savvies ERP Support Call CRM — Production Web Hosting Guide

This guide provides instructions and pre-configured deployment files to host the **Tech Savvies CRM** and **Customer Complaint Portal** on the web.

---

## 🏗️ Architecture Overview

The application consists of two dedicated portals sharing the same high-performance SQLite database:

| Component | Port | Description |
| :--- | :--- | :--- |
| **CRM Staff & Admin Portal** | `3000` | Internal portal for administrators and technical support engineers (`/admin`, `/employee`, `/reports`, `/auth`). |
| **Customer Complaint Portal** | `3001` | Public customer portal for submitting complaints, tracking tickets, and self-service account management (`/customer`, `/complaint`, `/track`). |
| **Unified Web Gateway** | `8080` / `80` | Optional single-port reverse proxy (`gateway.js`) routing both portals behind one public URL (ideal for Render, Railway, Heroku). |

---

## 📁 Pre-Configured Hosting Files Included in Project

| File | Purpose |
| :--- | :--- |
| [gateway.js](file:///d:/App/CRM_Tech%20Savvies/gateway.js) | Production single-port gateway routing both portals behind one public URL. |
| [Dockerfile](file:///d:/App/CRM_Tech%20Savvies/Dockerfile) | Production Alpine container definition running both portals with healthchecks. |
| [docker-compose.yml](file:///d:/App/CRM_Tech%20Savvies/docker-compose.yml) | Docker Compose with persistent data volumes for database and file uploads. |
| [deploy/setup-vps.sh](file:///d:/App/CRM_Tech%20Savvies/deploy/setup-vps.sh) | Automated 1-click provisioning script for Ubuntu VPS (Node 20, Nginx, PM2, UFW). |
| [deploy/nginx-subdomains.conf](file:///d:/App/CRM_Tech%20Savvies/deploy/nginx-subdomains.conf) | Nginx config for `crm.yourdomain.com` (3000) and `support.yourdomain.com` (3001). |
| [deploy/nginx-singledomain.conf](file:///d:/App/CRM_Tech%20Savvies/deploy/nginx-singledomain.conf) | Nginx config for single domain: `yourdomain.com/` and `yourdomain.com/customer`. |
| [deploy/techsavvies-all.service](file:///d:/App/CRM_Tech%20Savvies/deploy/techsavvies-all.service) | Linux systemd service for running dual servers with auto-restart on boot. |
| [ecosystem.config.js](file:///d:/App/CRM_Tech%20Savvies/ecosystem.config.js) | PM2 cluster/process manager configuration. |
| [render.yaml](file:///d:/App/CRM_Tech%20Savvies/render.yaml) | Render.com blueprint specification with persistent disk. |
| [railway.json](file:///d:/App/CRM_Tech%20Savvies/railway.json) | Railway.app configuration. |

---

## Method 1: Ubuntu / Debian VPS (Recommended for Business Production)

Recommended cloud providers: **AWS EC2, DigitalOcean Droplet, Hetzner, Hostinger, Linode**.

### Step 1: Run Automated VPS Provisioning
Connect to your fresh Ubuntu server via SSH and run:
```bash
# Upload or clone repository to /var/www/techsavvies-crm
sudo mkdir -p /var/www/techsavvies-crm
cd /var/www/techsavvies-crm

# Run automated setup script
sudo bash deploy/setup-vps.sh
```

### Step 2: Install Dependencies & Setup Environment
```bash
cd /var/www/techsavvies-crm
npm install --omit=dev

# Configure environment variables
cp .env.production.example .env
nano .env
```
Ensure `.env` contains:
```env
CRM_PORT=3000
CUSTOMER_PORT=3001
CRM_URL=https://crm.yourdomain.com
CUSTOMER_URL=https://support.yourdomain.com
SESSION_SECRET=generate_a_random_long_secret_key_here
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=support@yourdomain.com
SMTP_PASS=your-google-app-password
```

### Step 3: Start with PM2 Process Manager
```bash
# Start both CRM and Customer Portal instances
pm2 start ecosystem.config.js --env production

# Save PM2 process list to auto-start on server reboot
pm2 save
pm2 startup
```

### Step 4: Configure Nginx & Free SSL (Let's Encrypt)
**For Subdomain Setup (`crm.yourdomain.com` & `support.yourdomain.com`):**
```bash
sudo cp deploy/nginx-subdomains.conf /etc/nginx/sites-available/techsavvies-crm
sudo ln -s /etc/nginx/sites-available/techsavvies-crm /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx

# Issue free SSL certificates
sudo certbot --nginx -d crm.yourdomain.com -d support.yourdomain.com
```

**For Single Domain Setup (`yourdomain.com`):**
```bash
sudo cp deploy/nginx-singledomain.conf /etc/nginx/sites-available/techsavvies-crm
sudo ln -s /etc/nginx/sites-available/techsavvies-crm /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx

sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com
```

---

## Method 2: Docker & Docker Compose (Zero-Config Container)

Deploy to any server running Docker with a single command:

```bash
# 1. Copy project files to server
cd /var/www/techsavvies-crm

# 2. Configure environment
cp .env.production.example .env

# 3. Launch both containers with persistent database volumes
docker compose up -d --build
```

Ports exposed:
- `http://your-server-ip:3000` — CRM Staff & Admin
- `http://your-server-ip:3001` — Customer Complaint Portal

The database and uploaded files are stored safely on the host machine at `./data` and `./public/uploads`.

---

## Method 3: Cloud PaaS (Render.com)

Render provides managed hosting with free automated HTTPS:

1. Push your CRM code to a private GitHub repository.
2. In [Render Dashboard](https://dashboard.render.com), click **New + Blueprint** and connect your repository (it automatically reads [render.yaml](file:///d:/App/CRM_Tech%20Savvies/render.yaml)).
3. Or create a **New Web Service**:
   - **Build Command**: `npm install --omit=dev`
   - **Start Command**: `node gateway.js`
   - **Disk**: Add a Persistent Disk mounted at `/usr/src/app/data` (size: 1 GB) so the SQLite database is never lost across deploys.
   - **Environment Variables**:
     - `NODE_ENV=production`
     - `SESSION_SECRET=(generate random string)`
     - `SMTP_USER` and `SMTP_PASS` (for email notifications)

---

## Method 4: Cloud PaaS (Railway.app)

1. Install Railway CLI or connect via GitHub on [Railway.app](https://railway.app).
2. Create project from GitHub repo.
3. Under **Settings > Volumes**, attach a persistent volume to `/usr/src/app/data`.
4. Railway will use [railway.json](file:///d:/App/CRM_Tech%20Savvies/railway.json) to build and run `node gateway.js`.

---

## 🗄️ Database Backup & Maintenance

The CRM stores all records in `data/techsavvies.db` with SQLite Write-Ahead Logging (WAL) enabled.

### Automated Nightly Backup Cron Job
To back up the database every midnight on a Linux server:
```bash
sudo crontab -e
```
Add this line:
```cron
0 0 * * * sqlite3 /var/www/techsavvies-crm/data/techsavvies.db ".backup '/var/backups/techsavvies-backup-$(date +\%F).db'"
```
This safely creates an online backup without stopping the CRM or interrupting users.
