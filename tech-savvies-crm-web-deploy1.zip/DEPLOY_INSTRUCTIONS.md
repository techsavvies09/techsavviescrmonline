# Tech Savvies CRM — Web Deployment Guide

## ⚠️ Why Netlify Showed "Page Cannot Be Found" (404)
- **Netlify is a static website host**: It only serves pre-built HTML, CSS, and client-side JavaScript. It looks for an `index.html` file in the root.
- **Tech Savvies CRM is a dynamic Node.js + Express application**: It uses server-side EJS templates and an embedded SQLite database (`better-sqlite3`). Netlify cannot run `node server.js` or persist SQLite databases.

---

## 🚀 Recommended Hosting Solutions (Choose 1)

### Option 1: Render.com (Recommended Free / Cloud Hosting)
Render runs Node.js natively and supports persistent storage for your database.

1. Create a free account at [Render.com](https://render.com).
2. Create a new GitHub repository and upload your files (or push via Git).
3. In Render dashboard:
   - Click **New +** > **Web Service**
   - Connect your GitHub repository
   - **Build Command**: `npm install`
   - **Start Command**: `node server.js`
   - Under **Advanced / Disks**: Add a Persistent Disk mounted at `/data` (1 GB)
   - Add Environment Variable: `NODE_ENV=production`, `DATA_DIR=/data`
4. Click **Create Web Service**. Render will deploy your CRM and provide a live URL like `https://techsavvies-crm.onrender.com`.

---

### Option 2: Railway.app (Easiest Docker / Git Deployment)
1. Sign up at [Railway.app](https://railway.app).
2. Click **New Project** > **Deploy from GitHub repo**.
3. Railway automatically detects the included `Dockerfile` and `railway.json`.
4. Under the service settings, add a **Volume** mounted at `/data`.
5. Your application goes live instantly with a free `.up.railway.app` HTTPS domain.

---

### Option 3: Instant Web URL from this PC (Cloudflare Tunnel - 100% Free)
If you want to use the CRM right now from mobile or outside offices without uploading to the cloud:
1. Download [Cloudflare Tunnel (cloudflared)](https://github.com/cloudflare/cloudflared/releases).
2. Open terminal and run:
   ```cmd
   cloudflared tunnel --url http://localhost:3000
   ```
3. Cloudflare will instantly give you a secure public URL (e.g., `https://random-words.trycloudflare.com`) that anyone on your team can open in their browser!

---

### Option 4: Linux VPS / Cloud Server (Ubuntu / Debian / AWS / DigitalOcean)
A complete deployment zip is already created at:
`d:\App\CRM_Tech Savvies\deploy\tech-savvies-crm-web-deploy.zip`

1. Upload `tech-savvies-crm-web-deploy.zip` to your server.
2. Extract the files:
   ```bash
   unzip tech-savvies-crm-web-deploy.zip -d /var/www/techsavvies-crm
   cd /var/www/techsavvies-crm
   ```
3. Install dependencies:
   ```bash
   npm install --production
   ```
4. Start with PM2:
   ```bash
   npm install -g pm2
   pm2 start ecosystem.config.js
   pm2 save
   pm2 startup
   ```
5. Configure Nginx (see `deploy/nginx.conf`) to point your domain to `http://localhost:3000`.

---

## 📦 What Was Created for Web Hosting:
| File | Purpose |
|------|---------|
| `deploy/tech-savvies-crm-web-deploy.zip` | Ready-to-upload ZIP package (no bulky `node_modules`) |
| `render.yaml` | 1-Click Render.com Blueprint configuration |
| `railway.json` | 1-Click Railway.app configuration |
| `Dockerfile` & `docker-compose.yml` | Container deployment for any Docker cloud |
| `.gitignore` & `.dockerignore` | Clean separation of code and environment files |
| `deploy/nginx.conf` | Reverse proxy with SSL configuration |
| `deploy/techsavvies-crm.service` | Linux systemd background service |
| `ecosystem.config.js` | PM2 cluster manager configuration |
| `data/database-dump.sql` | SQL export for external MySQL/PostgreSQL migration |
