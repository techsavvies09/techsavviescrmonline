// Tech Savvies ERP Support Call CRM - Customer Portal & Complaint Registration Routes
const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const { isCustomer } = require('../middleware/auth');
const { getDb, generateTicketNo, generateCode, logAudit } = require('../config/database');
const { sendComplaintRegistrationNotification, sendSMS } = require('../config/notifications');

// ═══════════════════════════════════════════════════
//  CUSTOMER LOGIN
// ═══════════════════════════════════════════════════
router.get('/login', (req, res) => {
  if (req.session.customer) {
    return res.redirect('/customer/dashboard');
  }
  res.render('customer/login');
});

router.post('/login', async (req, res) => {
  const { identifier, password } = req.body;
  const db = getDb();

  if (!identifier || !password) {
    req.flash('error', 'Please enter your Mobile / Customer Code / Email and Password');
    return res.redirect('/customer/login');
  }

  try {
    const cleanId = identifier.trim();
    const customer = db.prepare(`
      SELECT * FROM customers 
      WHERE is_active = 1 
        AND (mobile = ? OR customer_code = ? OR email = ? OR portal_username = ?)
    `).get(cleanId, cleanId, cleanId, cleanId);

    if (!customer) {
      req.flash('error', 'Customer account not found. Please register or register a direct complaint.');
      return res.redirect('/customer/login');
    }

    if (customer.portal_enabled === 0) {
      req.flash('error', 'Your customer portal access has been disabled. Please contact support.');
      return res.redirect('/customer/login');
    }

    // Check password if set
    let passwordValid = false;
    if (customer.password) {
      passwordValid = await bcrypt.compare(password, customer.password);
    } else {
      // If customer has no password set yet, default password is their mobile number or Admin@123
      if (password === customer.mobile || password === 'Customer@123') {
        passwordValid = true;
        // Hash and store the password now
        const hashed = await bcrypt.hash(password, 10);
        db.prepare("UPDATE customers SET password = ? WHERE id = ?").run(hashed, customer.id);
      }
    }

    if (!passwordValid) {
      req.flash('error', 'Invalid password. (Default password is your mobile number if not changed)');
      return res.redirect('/customer/login');
    }

    // Set customer session
    req.session.customer = {
      id: customer.id,
      customer_code: customer.customer_code,
      name: customer.name,
      company: customer.company,
      email: customer.email,
      mobile: customer.mobile,
      plan_version: customer.plan_version
    };

    logAudit(null, 'CUSTOMER_LOGIN', `Customer ${customer.name} (${customer.customer_code}) logged into portal`, req.ip);

    req.flash('success', `Welcome back, ${customer.name}!`);
    res.redirect('/customer/dashboard');
  } catch (err) {
    console.error('Customer login error:', err);
    req.flash('error', 'Login error: ' + err.message);
    res.redirect('/customer/login');
  }
});

// ═══════════════════════════════════════════════════
//  CUSTOMER REGISTRATION
// ═══════════════════════════════════════════════════
router.get('/register', (req, res) => {
  if (req.session.customer) {
    return res.redirect('/customer/dashboard');
  }
  const db = getDb();
  const plans = db.prepare("SELECT plan_name FROM plan_versions WHERE is_active = 1 ORDER BY plan_name").all();
  res.render('customer/register', { plans });
});

router.post('/register', async (req, res) => {
  const { name, company, mobile, email, plan_version, address, city, password, confirm_password } = req.body;
  const db = getDb();

  if (!name || !mobile || !password) {
    req.flash('error', 'Name, Mobile Number, and Password are required.');
    return res.redirect('/customer/register');
  }

  if (password !== confirm_password) {
    req.flash('error', 'Passwords do not match.');
    return res.redirect('/customer/register');
  }

  if (password.length < 6) {
    req.flash('error', 'Password must be at least 6 characters long.');
    return res.redirect('/customer/register');
  }

  try {
    const cleanMobile = mobile.trim();
    const cleanEmail = email ? email.trim() : null;

    // Check if customer already exists in Customer Master
    const existing = db.prepare(`
      SELECT * FROM customers 
      WHERE mobile = ? OR (email IS NOT NULL AND email != '' AND email = ?)
    `).get(cleanMobile, cleanEmail);

    const hashedPassword = await bcrypt.hash(password, 10);

    let customerId;
    let customerCode;

    if (existing) {
      // Update existing customer record with portal credentials
      db.prepare(`
        UPDATE customers 
        SET name = COALESCE(?, name),
            company = COALESCE(?, company),
            email = COALESCE(?, email),
            plan_version = COALESCE(?, plan_version),
            address = COALESCE(?, address),
            city = COALESCE(?, city),
            password = ?,
            portal_enabled = 1,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(name.trim(), company || null, cleanEmail, plan_version || null, address || null, city || null, hashedPassword, existing.id);

      customerId = existing.id;
      customerCode = existing.customer_code;
    } else {
      // Create new customer
      customerCode = generateCode('CUS', 'customers', 'customer_code');
      const info = db.prepare(`
        INSERT INTO customers (customer_code, name, company, email, mobile, plan_version, address, city, password, portal_enabled)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
      `).run(customerCode, name.trim(), company || '', cleanEmail || '', cleanMobile, plan_version || 'Default', address || '', city || '', hashedPassword);

      customerId = info.lastInsertRowid;
    }

    // Set session
    req.session.customer = {
      id: customerId,
      customer_code: customerCode,
      name: name.trim(),
      company: company || '',
      email: cleanEmail || '',
      mobile: cleanMobile,
      plan_version: plan_version || 'Default'
    };

    logAudit(null, 'CUSTOMER_REGISTER', `New customer registered: ${name} (${customerCode})`, req.ip);

    req.flash('success', `Account created successfully! Your Customer Code is ${customerCode}. You can now file your support complaint.`);
    res.redirect('/customer/complaint');
  } catch (err) {
    console.error('Customer registration error:', err);
    req.flash('error', 'Registration error: ' + err.message);
    res.redirect('/customer/register');
  }
});

// ═══════════════════════════════════════════════════
//  COMPLAINT REGISTRATION FORM (Auto-fills on Call Records)
// ═══════════════════════════════════════════════════
router.get('/complaint', (req, res) => {
  const db = getDb();
  const customer = req.session.customer || null;
  const issues = db.prepare("SELECT id, category, sub_category, description, priority, estimated_time FROM issues_master WHERE is_active = 1 ORDER BY category, sub_category").all();
  const plans = db.prepare("SELECT plan_name FROM plan_versions WHERE is_active = 1 ORDER BY plan_name").all();

  res.render('customer/complaint', {
    customer,
    issues,
    plans
  });
});

router.post('/complaint', async (req, res) => {
  const db = getDb();
  const {
    name,
    company,
    mobile,
    email,
    plan_version,
    issue_id,
    issue_description,
    priority,
    preferred_contact_time
  } = req.body;

  try {
    let customerId;
    let customerName = name ? name.trim() : '';
    let customerMobile = mobile ? mobile.trim() : '';
    let customerEmail = email ? email.trim() : '';
    let customerCompany = company ? company.trim() : '';
    let customerPlan = plan_version || 'Standard';

    // 1. Identify Customer (either from session or from form inputs)
    if (req.session.customer) {
      customerId = req.session.customer.id;
      customerName = req.session.customer.name;
      customerMobile = req.session.customer.mobile;
      customerEmail = req.session.customer.email || customerEmail;
      customerCompany = req.session.customer.company || customerCompany;
      customerPlan = plan_version || req.session.customer.plan_version;
    } else {
      if (!customerName || !customerMobile) {
        req.flash('error', 'Please provide your Name and Mobile Number.');
        return res.redirect('/customer/complaint');
      }

      // Check if customer exists in Customer Master by mobile
      let existingCustomer = db.prepare("SELECT * FROM customers WHERE mobile = ?").get(customerMobile);
      if (existingCustomer) {
        customerId = existingCustomer.id;
        customerName = existingCustomer.name;
        if (customerPlan === 'Standard' && existingCustomer.plan_version) {
          customerPlan = existingCustomer.plan_version;
        }
      } else {
        // Automatically create in Customer Master so everything stays linked
        const customer_code = generateCode('CUS', 'customers', 'customer_code');
        const insertCust = db.prepare(`
          INSERT INTO customers (customer_code, name, company, email, mobile, plan_version)
          VALUES (?, ?, ?, ?, ?, ?)
        `).run(customer_code, customerName, customerCompany, customerEmail, customerMobile, customerPlan);
        customerId = insertCust.lastInsertRowid;
      }

      // Set customer session so they can track their ticket right away
      req.session.customer = {
        id: customerId,
        name: customerName,
        company: customerCompany,
        mobile: customerMobile,
        email: customerEmail,
        plan_version: customerPlan
      };
    }

    if (!issue_description || issue_description.trim() === '') {
      req.flash('error', 'Please provide a description of the issue or complaint.');
      return res.redirect('/customer/complaint');
    }

    // 2. Fetch issue master details if issue_id selected
    let selectedIssue = null;
    let categoryName = 'General Support';
    if (issue_id) {
      selectedIssue = db.prepare("SELECT * FROM issues_master WHERE id = ?").get(issue_id);
      if (selectedIssue) {
        categoryName = `${selectedIssue.category} - ${selectedIssue.sub_category || selectedIssue.description}`;
      }
    }

    // 3. Automatically Generate Ticket Number
    const ticket_no = generateTicketNo();
    const today = new Date().toISOString().slice(0, 10);
    const nowTime = new Date().toTimeString().slice(0, 5);

    // Formatted problem description
    let fullDescription = issue_description.trim();
    if (preferred_contact_time) {
      fullDescription += `\n[Preferred Callback: ${preferred_contact_time}]`;
    }

    // 4. AUTOMATICALLY FILL IN CALL RECORDS (Core Requirement)
    const complaintPriority = (priority === 'critical' || priority === 'high') ? priority : (selectedIssue && selectedIssue.priority === 'critical' ? 'critical' : 'medium');
    const isCritical = complaintPriority === 'critical';
    const initialStatus = isCritical ? 'escalated' : 'open';

    const result = db.prepare(`
      INSERT INTO call_records (
        ticket_no,
        customer_id,
        call_date,
        call_time,
        duration,
        plan_version,
        issue_id,
        issue_description,
        status,
        source
      ) VALUES (?, ?, ?, ?, 0, ?, ?, ?, ?, 'customer_portal')
    `).run(
      ticket_no,
      customerId,
      today,
      nowTime,
      customerPlan,
      issue_id || null,
      fullDescription,
      initialStatus
    );

    const callRecordId = result.lastInsertRowid;

    // If critical priority, automatically record an escalation transaction
    if (isCritical) {
      db.prepare(`
        INSERT INTO escalations (call_record_id, escalated_from, reason, priority, status)
        VALUES (?, NULL, ?, 'critical', 'pending')
      `).run(
        callRecordId,
        `Customer reported critical breakdown on complaint portal: ${fullDescription.slice(0, 250)}`
      );
    }

    // 5. Log audit trail
    logAudit(
      null,
      'CUSTOMER_COMPLAINT_REGISTERED',
      `Customer ${customerName} (${customerMobile}) registered complaint #${ticket_no}. Automatically logged into Call Records.`,
      req.ip
    );

    // 6. Send confirmation email/SMS
    if (customerEmail) {
      sendComplaintRegistrationNotification(
        { name: customerName, email: customerEmail },
        ticket_no,
        categoryName,
        fullDescription
      ).catch(e => console.error('Notification error:', e.message));
    }

    sendSMS(customerMobile, `Tech Savvies Support: Your complaint has been registered with Ticket #${ticket_no}. Our team will contact you shortly.`).catch(e => console.error('SMS error:', e.message));

    req.flash('success', `Complaint registered successfully! Your Ticket Number is ${ticket_no}. It has been added to our support queue.`);
    res.redirect('/customer/ticket/' + ticket_no);
  } catch (err) {
    console.error('Complaint registration error:', err);
    req.flash('error', 'Error filing complaint: ' + err.message);
    res.redirect('/customer/complaint');
  }
});

// ═══════════════════════════════════════════════════
//  CUSTOMER DASHBOARD (MY COMPLAINTS / TICKETS)
// ═══════════════════════════════════════════════════
router.get('/dashboard', isCustomer, (req, res) => {
  const db = getDb();
  const customerId = req.session.customer.id;

  const customer = db.prepare("SELECT * FROM customers WHERE id = ?").get(customerId);
  const tickets = db.prepare(`
    SELECT cr.*, 
           im.category, im.sub_category, im.description as issue_master_name,
           e.name as employee_name, e.phone as employee_phone
    FROM call_records cr
    LEFT JOIN issues_master im ON cr.issue_id = im.id
    LEFT JOIN employees e ON cr.employee_id = e.id
    WHERE cr.customer_id = ?
    ORDER BY cr.created_at DESC
  `).all(customerId);

  const stats = {
    total: tickets.length,
    open: tickets.filter(t => t.status === 'open' || t.status === 'assigned').length,
    in_progress: tickets.filter(t => t.status === 'in_progress').length,
    resolved: tickets.filter(t => t.status === 'resolved' || t.status === 'closed').length,
    escalated: tickets.filter(t => t.status === 'escalated').length
  };

  res.render('customer/dashboard', {
    customer: customer || req.session.customer,
    tickets,
    stats
  });
});

// ═══════════════════════════════════════════════════
//  VIEW SPECIFIC TICKET / LIVE STATUS
// ═══════════════════════════════════════════════════
router.get('/ticket/:ticket_no', (req, res) => {
  const db = getDb();
  const ticket = db.prepare(`
    SELECT cr.*, 
           c.name as customer_name, c.mobile as customer_mobile, c.email as customer_email, c.company as customer_company,
           im.category, im.sub_category, im.description as issue_master_name, im.estimated_time,
           e.name as employee_name, e.designation as employee_designation,
           rb.name as resolved_by_name
    FROM call_records cr
    LEFT JOIN customers c ON cr.customer_id = c.id
    LEFT JOIN issues_master im ON cr.issue_id = im.id
    LEFT JOIN employees e ON cr.employee_id = e.id
    LEFT JOIN employees rb ON cr.resolved_by = rb.id
    WHERE cr.ticket_no = ?
  `).get(req.params.ticket_no);

  if (!ticket) {
    req.flash('error', 'Ticket not found.');
    return res.redirect('/customer/track');
  }

  res.render('customer/ticket-view', { ticket });
});

// ═══════════════════════════════════════════════════
//  PUBLIC TICKET TRACKING
// ═══════════════════════════════════════════════════
router.get('/track', (req, res) => {
  res.render('customer/track', { results: null, query: '' });
});

router.post('/track', (req, res) => {
  const db = getDb();
  const { search_query } = req.body;

  if (!search_query || search_query.trim() === '') {
    req.flash('error', 'Please enter a Ticket Number or Mobile Number.');
    return res.redirect('/customer/track');
  }

  const query = search_query.trim();

  // Search by ticket_no or mobile
  const results = db.prepare(`
    SELECT cr.*, 
           c.name as customer_name, c.mobile as customer_mobile,
           im.category, im.sub_category,
           e.name as employee_name
    FROM call_records cr
    LEFT JOIN customers c ON cr.customer_id = c.id
    LEFT JOIN issues_master im ON cr.issue_id = im.id
    LEFT JOIN employees e ON cr.employee_id = e.id
    WHERE cr.ticket_no LIKE ? OR c.mobile = ? OR c.customer_code = ?
    ORDER BY cr.created_at DESC
  `).all(`%${query}%`, query, query);

  if (results.length === 1 && results[0].ticket_no.toLowerCase() === query.toLowerCase()) {
    return res.redirect('/customer/ticket/' + results[0].ticket_no);
  }

  res.render('customer/track', { results, query });
});

// ═══════════════════════════════════════════════════
//  LOGOUT
// ═══════════════════════════════════════════════════
router.get('/logout', (req, res) => {
  req.session.customer = null;
  req.flash('success', 'You have been logged out of the Customer Portal.');
  res.redirect('/customer/login');
});

module.exports = router;
