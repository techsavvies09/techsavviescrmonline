#!/usr/bin/env bash
# ==============================================================
# Tech Savvies CRM - Ubuntu VPS Automated Provisioning Script
# Tested on Ubuntu 20.04 / 22.04 / 24.04 LTS
# ==============================================================

set -e

echo "=========================================================="
echo "   Tech Savvies CRM & Customer Portal VPS Provisioning"
echo "=========================================================="

if [ "$EUID" -ne 0 ]; then
  echo "[-] Please run as root (use sudo bash setup-vps.sh)"
  exit 1
fi

echo "[*] Step 1: Updating system packages..."
apt-get update -y
apt-get upgrade -y
apt-get install -y curl wget git build-essential sqlite3 python3 nginx certbot python3-certbot-nginx ufw

echo "[*] Step 2: Installing Node.js 20 LTS..."
if ! command -v node &> /dev/null; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
fi
node -v
npm -v

echo "[*] Step 3: Installing PM2 process manager globally..."
npm install -g pm2

echo "[*] Step 4: Setting up application directory..."
mkdir -p /var/www/techsavvies-crm
cd /var/www/techsavvies-crm

# Ensure persistent directories exist
mkdir -p data public/uploads

echo "[*] Step 5: Setting permissions..."
chown -R www-data:www-data /var/www/techsavvies-crm
chmod -R 775 /var/www/techsavvies-crm/data
chmod -R 775 /var/www/techsavvies-crm/public/uploads

echo "[*] Step 6: Configuring Firewall (UFW)..."
ufw allow OpenSSH
ufw allow 'Nginx Full'
ufw --force enable

echo "=========================================================="
echo " [OK] Server provisioned successfully!"
echo " Next steps:"
echo " 1. Copy your application code to: /var/www/techsavvies-crm"
echo " 2. Run: npm install --omit=dev"
echo " 3. Copy .env.production.example to .env and configure secrets"
echo " 4. Start PM2: pm2 start ecosystem.config.js --env production"
echo " 5. Save PM2 startup: pm2 save && pm2 startup"
echo " 6. Setup SSL: certbot --nginx -d crm.yourdomain.com -d support.yourdomain.com"
echo "=========================================================="
