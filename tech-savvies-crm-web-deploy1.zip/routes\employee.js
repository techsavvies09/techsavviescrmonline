// Tech Savvies ERP Support Call CRM - Employee Routes
const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { isAuthenticated, isEmployee } = require('../middleware/auth');
const { getDb, generateCode, logAudit } = require('../config/database');
const { sendResolutionNotification, sendEscalationNotification } = require('../config/notifications');

// File upload setup
const uploadsDir = path.join(__dirname, '..', 'public', 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, '..', 'public', 'uploads')),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage });

// Apply auth middleware
router.use(isAuthenticated, isEmployee);

// Helper function to get or ensure employee profile exists for user
function getOrCreateEmployee(db, user) {
  let employee = db.prepare('SELECT * FROM employees WHERE user_id = ?').get(user.id);
  if (!employee) {
    const empCode = generateCode('EMP', 'employees', 'emp_code');
    db.prepare(`
      INSERT INTO employees (user_id, emp_code, name, email, phone, designation, department, address)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      user.id,
      empCode,
      user.username,
      user.email,
      '',
      user.role === 'admin' ? 'Administrator' : 'Support Engineer',
      'Technical Support',
      ''
    );
    employee = db.prepare('SELECT * FROM employees WHERE user_id = ?').get(user.id);
  }
  return employee;
}

// ═══════════════════════════════════════════════════
//  EMPLOYEE DASHBOARD (Each employee has their own dashboard)
// ═══════════════════════════════════════════════════
router.get('/dashboard', isAuthenticated, isEmployee, (req, res) => {
  try {
    const db = getDb();
    const employee = getOrCreateEmployee(db, req.session.user);
    const employeeId = employee.id;

    const stats = {
      assigned: db.prepare(
        "SELECT COUNT(*) as count FROM call_records WHERE employee_id = ? AND status IN ('assigned', 'open')"
      ).get(employeeId)?.count || 0,

      in_progress: db.prepare(
        "SELECT COUNT(*) as count FROM call_records WHERE employee_id = ? AND status = 'in_progress'"
      ).get(employeeId)?.count || 0,

      resolved: db.prepare(
        "SELECT COUNT(*) as count FROM call_records WHERE employee_id = ? AND status = 'resolved'"
      ).get(employeeId)?.count || 0,

      escalated: db.prepare(
        "SELECT COUNT(*) as count FROM call_records WHERE employee_id = ? AND status = 'escalated'"
      ).get(employeeId)?.count || 0,

      total: db.prepare(
        "SELECT COUNT(*) as count FROM call_records WHERE employee_id = ?"
      ).get(employeeId)?.count || 0
    };

    const recentCalls = db.prepare(`
      SELECT cr.*, 
             c.name as customer_name, c.mobile, c.company as customer_company,
             im.description as issue_name
      FROM call_records cr
      LEFT JOIN customers c ON cr.customer_id = c.id
      LEFT JOIN issues_master im ON cr.issue_id = im.id
      WHERE cr.employee_id = ?
      ORDER BY cr.created_at DESC
      LIMIT 10
    `).all(employeeId);

    res.render('employee/dashboard', {
      employee,
      stats,
      recentCalls
    });
  } catch (error) {
    console.error('Error loading employee dashboard:', error);
    req.flash('error', 'Error loading dashboard');
    res.redirect('/');
  }
});

// ═══════════════════════════════════════════════════
//  MY CALLS LIST
// ═══════════════════════════════════════════════════
router.get('/calls', isAuthenticated, isEmployee, (req, res) => {
  try {
    const db = getDb();
    const employee = getOrCreateEmployee(db, req.session.user);
    const employeeId = employee.id;
    const status = req.query.status || '';

    let query = `
      SELECT cr.*, 
             c.name as customer_name, c.mobile, c.company as customer_company,
             im.description as issue_name
      FROM call_records cr
      LEFT JOIN customers c ON cr.customer_id = c.id
      LEFT JOIN issues_master im ON cr.issue_id = im.id
      WHERE cr.employee_id = ?
    `;
    const params = [employeeId];

    if (status && status !== 'all') {
      query += ' AND cr.status = ?';
      params.push(status);
    }

    query += ' ORDER BY cr.created_at DESC';
    const calls = db.prepare(query).all(...params);

    res.render('employee/calls', {
      calls,
      filters: { status }
    });
  } catch (error) {
    console.error('Error loading calls:', error);
    req.flash('error', 'Error loading call list');
    res.redirect('/employee/dashboard');
  }
});

// ═══════════════════════════════════════════════════
//  SELF-LOG CALL (Employee directly records their own call)
// ═══════════════════════════════════════════════════
router.get('/calls/log', isAuthenticated, isEmployee, (req, res) => {
  try {
    const db = getDb();
    const customers = db.prepare("SELECT id, name, company, customer_code, plan_version FROM customers WHERE is_active = 1 ORDER BY name").all();
    const issues = db.prepare("SELECT id, category, sub_category, description FROM issues_master WHERE is_active = 1 ORDER BY category, sub_category").all();
    const plans = db.prepare("SELECT plan_name FROM plan_versions WHERE is_active = 1 ORDER BY plan_name").all();

    res.render('employee/call-log', {
      customers,
      issues,
      plans,
      selectedCustomerId: req.query.customer_id || ''
    });
  } catch (error) {
    console.error('Error loading self call log form:', error);
    req.flash('error', 'Error loading call log form');
    res.redirect('/employee/calls');
  }
});

router.post('/calls/log', isAuthenticated, isEmployee, async (req, res) => {
  try {
    const db = getDb();
    const employee = getOrCreateEmployee(db, req.session.user);
    const { customer_id, call_date, call_time, duration, plan_version, issue_id, issue_description, status, resolution_notes } = req.body;
    const ticket_no = require('../config/database').generateTicketNo();

    const callStatus = status || 'in_progress';
    const isResolved = callStatus === 'resolved';

    let resolvedAt = isResolved ? new Date().toISOString() : null;
    let resolvedBy = isResolved ? employee.id : null;

    const insertTx = db.transaction(() => {
      // 1. Insert call record assigned directly to current employee
      const result = db.prepare(`
        INSERT INTO call_records (
          ticket_no, customer_id, employee_id, call_date, call_time, duration, 
          plan_version, issue_id, issue_description, status, resolution_notes, 
          resolved_at, resolved_by, created_by
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        ticket_no,
        customer_id,
        employee.id,
        call_date || new Date().toISOString().slice(0, 10),
        call_time || new Date().toTimeString().slice(0, 5),
        parseInt(duration) || 0,
        plan_version || null,
        issue_id || null,
        issue_description || '',
        callStatus,
        resolution_notes || '',
        resolvedAt,
        resolvedBy,
        req.session.user.id
      );

      // 2. Insert call allocation record indicating self-allocation/take
      db.prepare(`
        INSERT INTO call_allocations (call_record_id, allocated_to, allocated_by, status, notes)
        VALUES (?, ?, ?, 'accepted', 'Self-recorded by support engineer')
      `).run(result.lastInsertRowid, employee.id, req.session.user.id);

      // 3. If recorded as escalated, insert escalation transaction
      if (callStatus === 'escalated') {
        db.prepare(`
          INSERT INTO escalations (call_record_id, escalated_from, reason, priority, status)
          VALUES (?, ?, ?, 'high', 'pending')
        `).run(result.lastInsertRowid, employee.id, resolution_notes || issue_description || 'Self-recorded as escalated at intake');
      }

      return result.lastInsertRowid;
    });

    const newCallId = insertTx();

    logAudit(req.session.user.id, 'SELF_RECORD_CALL', `Employee ${employee.name} (${employee.emp_code}) self-recorded ticket #${ticket_no} (Status: ${callStatus})`, req.ip);

    // If resolved immediately, send email/sms notification to customer
    if (isResolved) {
      const customer = db.prepare('SELECT * FROM customers WHERE id = ?').get(customer_id);
      if (customer && customer.email) {
        try {
          await sendResolutionNotification(
            customer,
            ticket_no,
            issue_description || 'Support Call',
            resolution_notes || 'Resolved on call'
          );
        } catch (nErr) {
          console.error('Resolution notification error on self-log:', nErr);
        }
      }
    }

    req.flash('success', `Call successfully recorded (Ticket #${ticket_no})!`);
    res.redirect('/employee/calls/' + newCallId);
  } catch (error) {
    console.error('Error self-recording call:', error);
    req.flash('error', 'Error recording call: ' + error.message);
    res.redirect('/employee/calls/log');
  }
});

// ═══════════════════════════════════════════════════
//  VIEW SINGLE CALL
// ═══════════════════════════════════════════════════
router.get('/calls/:id', isAuthenticated, isEmployee, (req, res) => {
  try {
    const db = getDb();
    const employee = getOrCreateEmployee(db, req.session.user);

    const call = db.prepare(`
      SELECT cr.*, 
             c.name as customer_name, c.mobile, c.email as customer_email, 
             c.company as customer_company, c.address as customer_address, c.customer_code,
             im.description as issue_name, im.category as issue_category, im.priority as issue_priority,
             e.name as employee_name
      FROM call_records cr
      LEFT JOIN customers c ON cr.customer_id = c.id
      LEFT JOIN issues_master im ON cr.issue_id = im.id
      LEFT JOIN employees e ON cr.employee_id = e.id
      WHERE cr.id = ?
    `).get(req.params.id);

    if (!call) {
      req.flash('error', 'Call record not found');
      return res.redirect('/employee/calls');
    }

    // Check if escalation exists for this call
    const escalation = db.prepare(
      'SELECT * FROM escalations WHERE call_record_id = ? ORDER BY id DESC LIMIT 1'
    ).get(call.id);

    res.render('employee/call-view', {
      call,
      escalation,
      employee
    });
  } catch (error) {
    console.error('Error viewing call details:', error);
    req.flash('error', 'Error loading call details');
    res.redirect('/employee/calls');
  }
});

// ═══════════════════════════════════════════════════
//  UPDATE CALL STATUS
// ═══════════════════════════════════════════════════
router.post('/calls/:id/update-status', isAuthenticated, isEmployee, async (req, res) => {
  try {
    const db = getDb();
    const employee = getOrCreateEmployee(db, req.session.user);
    const { status, resolution_notes } = req.body;

    const call = db.prepare(`
      SELECT cr.*, c.name as customer_name, c.email as customer_email, c.mobile as customer_mobile
      FROM call_records cr
      LEFT JOIN customers c ON cr.customer_id = c.id
      WHERE cr.id = ?
    `).get(req.params.id);

    if (!call) {
      req.flash('error', 'Call record not found');
      return res.redirect('/employee/calls');
    }

    const employeeId = employee.id;

    if (status === 'resolved') {
      db.prepare(`
        UPDATE call_records
        SET status = 'resolved',
            resolution_notes = ?,
            resolved_at = datetime('now'),
            resolved_by = ?,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(resolution_notes || '', employeeId, req.params.id);

      logAudit(req.session.user.id, 'RESOLVE_CALL', `Resolved ticket #${call.ticket_no}`, req.ip);

      // Get customer info and send resolution notification
      const customer = db.prepare('SELECT * FROM customers WHERE id = ?').get(call.customer_id);
      if (customer) {
        try {
          await sendResolutionNotification(
            customer,
            call.ticket_no,
            call.issue_description || 'Support Call',
            resolution_notes || 'Issue marked as resolved.'
          );
        } catch (notifyErr) {
          console.error('Error sending resolution notification:', notifyErr);
        }
      }

      // Update any pending escalations to resolved
      db.prepare(`
        UPDATE escalations 
        SET status = 'resolved', resolved_at = datetime('now'), resolution_notes = ? 
        WHERE call_record_id = ? AND status != 'resolved'
      `).run(resolution_notes || 'Resolved by support engineer', req.params.id);

      req.flash('success', 'Call resolved successfully and notification sent to customer');
    } else {
      db.prepare(`
        UPDATE call_records
        SET status = ?,
            resolution_notes = ?,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(status, resolution_notes || '', req.params.id);

      // Record escalation transaction if status set to 'escalated'
      if (status === 'escalated') {
        const existingEsc = db.prepare("SELECT id FROM escalations WHERE call_record_id = ? AND status != 'resolved'").get(req.params.id);
        if (!existingEsc) {
          db.prepare(`
            INSERT INTO escalations (call_record_id, escalated_from, reason, priority, status)
            VALUES (?, ?, ?, 'high', 'pending')
          `).run(req.params.id, employeeId, resolution_notes || 'Escalated by support engineer via status update');
        }
      }

      logAudit(req.session.user.id, 'UPDATE_CALL_STATUS', `Updated ticket #${call.ticket_no} to ${status}`, req.ip);
      req.flash('success', `Call status updated to ${status.replace('_', ' ')}`);
    }

    res.redirect(`/employee/calls/${req.params.id}`);
  } catch (error) {
    console.error('Error updating call status:', error);
    req.flash('error', 'Failed to update call status: ' + error.message);
    res.redirect(`/employee/calls/${req.params.id}`);
  }
});

// ═══════════════════════════════════════════════════
//  ESCALATION FORM
// ═══════════════════════════════════════════════════
router.get('/escalate/:id', isAuthenticated, isEmployee, (req, res) => {
  try {
    const db = getDb();
    const call = db.prepare(`
      SELECT cr.*, 
             c.name as customer_name, c.mobile, c.email as customer_email, c.company as customer_company,
             im.description as issue_name, im.category as issue_category
      FROM call_records cr
      LEFT JOIN customers c ON cr.customer_id = c.id
      LEFT JOIN issues_master im ON cr.issue_id = im.id
      WHERE cr.id = ?
    `).get(req.params.id);

    if (!call) {
      req.flash('error', 'Call record not found');
      return res.redirect('/employee/calls');
    }

    res.render('employee/escalation', { call });
  } catch (error) {
    console.error('Error loading escalation form:', error);
    req.flash('error', 'Error loading escalation form');
    res.redirect('/employee/calls');
  }
});

// ═══════════════════════════════════════════════════
//  SUBMIT ESCALATION (TRANSACTION PROTECTED)
// ═══════════════════════════════════════════════════
router.post('/escalate/:id', isAuthenticated, isEmployee, (req, res) => {
  try {
    const db = getDb();
    const employee = getOrCreateEmployee(db, req.session.user);
    const { reason, priority } = req.body;

    const call = db.prepare('SELECT * FROM call_records WHERE id = ?').get(req.params.id);
    if (!call) {
      req.flash('error', 'Call record not found');
      return res.redirect('/employee/calls');
    }

    const escalatedFrom = employee ? employee.id : null;

    // Use transaction for atomic escalation handling
    const escalateTx = db.transaction(() => {
      // 1. Insert escalation record
      db.prepare(`
        INSERT INTO escalations (call_record_id, escalated_from, reason, priority, status)
        VALUES (?, ?, ?, ?, 'pending')
      `).run(req.params.id, escalatedFrom, reason, priority || 'high');

      // 2. Update call record status to 'escalated'
      db.prepare(`
        UPDATE call_records
        SET status = 'escalated',
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(req.params.id);
    });

    escalateTx();

    logAudit(req.session.user.id, 'ESCALATE_CALL', `Escalated ticket #${call.ticket_no} - Priority: ${priority}. Reason: ${reason}`, req.ip);

    req.flash('success', 'Call escalated successfully to senior management');
    if (req.session.user && req.session.user.role === 'admin') {
      res.redirect('/admin/escalations');
    } else {
      res.redirect('/employee/calls');
    }
  } catch (error) {
    console.error('Error submitting escalation:', error);
    req.flash('error', 'Failed to escalate call: ' + error.message);
    res.redirect(`/employee/calls/${req.params.id}`);
  }
});

// ═══════════════════════════════════════════════════
//  EMPLOYEE PROFILE
// ═══════════════════════════════════════════════════
router.get('/profile', isAuthenticated, isEmployee, (req, res) => {
  try {
    const db = getDb();
    const employee = getOrCreateEmployee(db, req.session.user);
    res.render('employee/profile', { employee });
  } catch (error) {
    console.error('Error loading profile:', error);
    req.flash('error', 'Error loading profile');
    res.redirect('/employee/dashboard');
  }
});

// ═══════════════════════════════════════════════════
//  UPDATE PROFILE
// ═══════════════════════════════════════════════════
router.post('/profile', isAuthenticated, isEmployee, upload.single('profile_pic'), (req, res) => {
  try {
    const db = getDb();
    const employee = getOrCreateEmployee(db, req.session.user);
    const { name, phone, address, designation } = req.body;

    if (req.file) {
      const profilePic = '/uploads/' + req.file.filename;
      db.prepare(`
        UPDATE employees
        SET name = ?, phone = ?, address = ?, designation = ?, profile_pic = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(name, phone, address, designation, profilePic, employee.id);
    } else {
      db.prepare(`
        UPDATE employees
        SET name = ?, phone = ?, address = ?, designation = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(name, phone, address, designation, employee.id);
    }

    logAudit(req.session.user.id, 'UPDATE_PROFILE', `Updated profile information for employee ${employee.emp_code}`, req.ip);

    req.flash('success', 'Profile updated successfully');
    res.redirect('/employee/profile');
  } catch (error) {
    console.error('Error updating profile:', error);
    req.flash('error', 'Failed to update profile');
    res.redirect('/employee/profile');
  }
});

// ═══════════════════════════════════════════════════
//  CUSTOMER MASTER (EMPLOYEE / USER ACCESS)
// ═══════════════════════════════════════════════════
router.get('/customers', isAuthenticated, isEmployee, (req, res) => {
  const db = getDb();
  const search = req.query.search ? req.query.search.trim() : '';
  let sql = 'SELECT * FROM customers WHERE 1=1';
  const params = [];
  if (search) {
    sql += ' AND (customer_code LIKE ? OR name LIKE ? OR company LIKE ? OR mobile LIKE ? OR email LIKE ?)';
    params.push(`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`);
  }
  sql += ' ORDER BY created_at DESC';
  const customers = db.prepare(sql).all(...params);
  res.render('employee/customers', { customers, search });
});

router.get('/customers/add', isAuthenticated, isEmployee, (req, res) => {
  const db = getDb();
  const plans = db.prepare("SELECT plan_name FROM plan_versions WHERE is_active = 1 ORDER BY plan_name").all();
  const returnTo = req.query.return_to || '';
  res.render('employee/customer-form', { customer: {}, isEdit: false, plans, returnTo });
});

router.post('/customers/add', isAuthenticated, isEmployee, (req, res) => {
  const db = getDb();
  const { name, company, email, mobile, phone, plan_version, address, city, state, pincode, gst_no, return_to } = req.body;
  const customer_code = generateCode('CUS', 'customers', 'customer_code');

  if (!name || !mobile) {
    req.flash('error', 'Customer Name and Mobile Number are required.');
    return res.redirect('/employee/customers/add' + (return_to ? `?return_to=${encodeURIComponent(return_to)}` : ''));
  }

  try {
    const insertRes = db.prepare(`
      INSERT INTO customers (customer_code, name, company, email, mobile, phone, plan_version, address, city, state, pincode, gst_no)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      customer_code, 
      name.trim(), 
      company ? company.trim() : '', 
      email ? email.trim() : '', 
      mobile.trim(), 
      phone ? phone.trim() : '', 
      plan_version || 'Standard', 
      address ? address.trim() : '', 
      city ? city.trim() : '', 
      state ? state.trim() : '', 
      pincode ? pincode.trim() : '', 
      gst_no ? gst_no.trim() : ''
    );

    logAudit(req.session.user.id, 'CREATE_CUSTOMER', `Employee ${req.session.user.username} created customer ${customer_code} - ${name}`, req.ip);
    req.flash('success', `Customer ${name} added successfully (Code: ${customer_code})`);

    if (return_to === 'log_call') {
      return res.redirect(`/employee/calls/log?customer_id=${insertRes.lastInsertRowid}`);
    }

    res.redirect('/employee/customers');
  } catch (err) {
    req.flash('error', 'Error adding customer: ' + err.message);
    res.redirect('/employee/customers/add' + (return_to ? `?return_to=${encodeURIComponent(return_to)}` : ''));
  }
});

router.get('/customers/edit/:id', isAuthenticated, isEmployee, (req, res) => {
  const db = getDb();
  const customer = db.prepare("SELECT * FROM customers WHERE id = ?").get(req.params.id);
  if (!customer) {
    req.flash('error', 'Customer not found');
    return res.redirect('/employee/customers');
  }
  const plans = db.prepare("SELECT plan_name FROM plan_versions WHERE is_active = 1 ORDER BY plan_name").all();
  res.render('employee/customer-form', { customer, isEdit: true, plans, returnTo: '' });
});

router.post('/customers/edit/:id', isAuthenticated, isEmployee, (req, res) => {
  const db = getDb();
  const { name, company, email, mobile, phone, plan_version, address, city, state, pincode, gst_no } = req.body;

  if (!name || !mobile) {
    req.flash('error', 'Customer Name and Mobile Number are required.');
    return res.redirect('/employee/customers/edit/' + req.params.id);
  }

  try {
    db.prepare(`
      UPDATE customers 
      SET name=?, company=?, email=?, mobile=?, phone=?, plan_version=?, address=?, city=?, state=?, pincode=?, gst_no=?, updated_at=CURRENT_TIMESTAMP
      WHERE id=?
    `).run(name.trim(), company, email, mobile.trim(), phone, plan_version, address, city, state, pincode, gst_no, req.params.id);

    logAudit(req.session.user.id, 'UPDATE_CUSTOMER', `Employee ${req.session.user.username} updated customer #${req.params.id} (${name})`, req.ip);
    req.flash('success', 'Customer updated successfully');
    res.redirect('/employee/customers');
  } catch (err) {
    req.flash('error', 'Error updating customer: ' + err.message);
    res.redirect('/employee/customers/edit/' + req.params.id);
  }
});

module.exports = router;
