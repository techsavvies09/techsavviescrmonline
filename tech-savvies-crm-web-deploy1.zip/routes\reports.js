// Tech Savvies ERP Support Call CRM - Reports Routes
const express = require('express');
const router = express.Router();
const { isAuthenticated, isAdmin } = require('../middleware/auth');
const { getDb } = require('../config/database');

// Apply authentication middleware to all report routes
router.use(isAuthenticated);

// ═══════════════════════════════════════════════════
//  1. DAILY CALL REPORT
// ═══════════════════════════════════════════════════
router.get('/daily', (req, res, next) => {
  try {
    const db = getDb();
    const selectedDate = req.query.date || new Date().toISOString().slice(0, 10);

    let query = `
      SELECT cr.*, 
             c.name AS customer_name, 
             c.mobile, 
             c.plan_version AS cust_plan, 
             e.name AS employee_name, 
             im.description AS issue_name 
      FROM call_records cr 
      LEFT JOIN customers c ON cr.customer_id = c.id 
      LEFT JOIN employees e ON cr.employee_id = e.id 
      LEFT JOIN issues_master im ON cr.issue_id = im.id 
      WHERE cr.call_date = ?
    `;
    const params = [selectedDate];

    // If user role is not admin, strictly restrict to only their assigned calls
    if (req.session.user && req.session.user.role !== 'admin') {
      const emp = db.prepare('SELECT id FROM employees WHERE user_id = ?').get(req.session.user.id);
      const empId = emp ? emp.id : -1;
      query += ` AND cr.employee_id = ?`;
      params.push(empId);
    }

    query += ` ORDER BY cr.call_time ASC`;

    const calls = db.prepare(query).all(...params);

    const stats = {
      total: calls.length,
      resolved: calls.filter(c => c.status === 'resolved').length,
      pending: calls.filter(c => c.status === 'open' || c.status === 'assigned' || c.status === 'in_progress').length,
      escalated: calls.filter(c => c.status === 'escalated').length
    };

    res.render('reports/daily', {
      calls,
      selectedDate,
      stats
    });
  } catch (err) {
    next(err);
  }
});

// ═══════════════════════════════════════════════════
//  2. ISSUED / OPEN CALLS REPORT
// ═══════════════════════════════════════════════════
router.get('/issued', (req, res, next) => {
  try {
    const db = getDb();

    let query = `
      SELECT cr.*, 
             c.name AS customer_name, 
             c.mobile, 
             c.plan_version AS cust_plan, 
             e.name AS employee_name, 
             im.description AS issue_name,
             im.priority AS issue_priority
      FROM call_records cr 
      LEFT JOIN customers c ON cr.customer_id = c.id 
      LEFT JOIN employees e ON cr.employee_id = e.id 
      LEFT JOIN issues_master im ON cr.issue_id = im.id 
      WHERE cr.status NOT IN ('resolved', 'closed')
    `;
    const params = [];

    if (req.session.user && req.session.user.role !== 'admin') {
      const emp = db.prepare('SELECT id FROM employees WHERE user_id = ?').get(req.session.user.id);
      const empId = emp ? emp.id : -1;
      query += ` AND cr.employee_id = ?`;
      params.push(empId);
    }

    query += ` ORDER BY cr.created_at DESC`;

    const calls = db.prepare(query).all(...params);

    res.render('reports/issued', {
      calls
    });
  } catch (err) {
    next(err);
  }
});

// ═══════════════════════════════════════════════════
//  3. RESOLVED CALLS REPORT
// ═══════════════════════════════════════════════════
router.get('/resolved', (req, res, next) => {
  try {
    const db = getDb();
    const today = new Date();
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(today.getDate() - 30);

    const fromDate = req.query.from_date || thirtyDaysAgo.toISOString().slice(0, 10);
    const toDate = req.query.to_date || today.toISOString().slice(0, 10);

    let query = `
      SELECT cr.*, 
             c.name AS customer_name, 
             c.mobile, 
             c.company, 
             e.name AS employee_name, 
             im.description AS issue_name,
             rb.name AS resolved_by_name
      FROM call_records cr 
      LEFT JOIN customers c ON cr.customer_id = c.id 
      LEFT JOIN employees e ON cr.employee_id = e.id 
      LEFT JOIN issues_master im ON cr.issue_id = im.id 
      LEFT JOIN employees rb ON cr.resolved_by = rb.id
      WHERE cr.status = 'resolved'
        AND date(cr.resolved_at) BETWEEN date(?) AND date(?)
    `;
    const params = [fromDate, toDate];

    if (req.session.user && req.session.user.role !== 'admin') {
      const emp = db.prepare('SELECT id FROM employees WHERE user_id = ?').get(req.session.user.id);
      const empId = emp ? emp.id : -1;
      query += ` AND (cr.employee_id = ? OR cr.resolved_by = ?)`;
      params.push(empId, empId);
    }

    query += ` ORDER BY cr.resolved_at DESC`;

    const calls = db.prepare(query).all(...params);

    res.render('reports/resolved', {
      calls,
      fromDate,
      toDate
    });
  } catch (err) {
    next(err);
  }
});

// ═══════════════════════════════════════════════════
//  4. PENDING CALLS REPORT
// ═══════════════════════════════════════════════════
router.get('/pending', (req, res, next) => {
  try {
    const db = getDb();

    let query = `
      SELECT cr.*, 
             c.name AS customer_name, 
             c.mobile, 
             c.company, 
             e.name AS employee_name, 
             im.description AS issue_name,
             im.priority AS issue_priority
      FROM call_records cr 
      LEFT JOIN customers c ON cr.customer_id = c.id 
      LEFT JOIN employees e ON cr.employee_id = e.id 
      LEFT JOIN issues_master im ON cr.issue_id = im.id 
      WHERE cr.status IN ('open', 'assigned', 'in_progress')
    `;
    const params = [];

    if (req.session.user && req.session.user.role !== 'admin') {
      const emp = db.prepare('SELECT id FROM employees WHERE user_id = ?').get(req.session.user.id);
      const empId = emp ? emp.id : -1;
      query += ` AND cr.employee_id = ?`;
      params.push(empId);
    }

    query += ` ORDER BY cr.call_date ASC, cr.call_time ASC`;

    const calls = db.prepare(query).all(...params);

    res.render('reports/pending', {
      calls
    });
  } catch (err) {
    next(err);
  }
});

// ═══════════════════════════════════════════════════
//  5. ESCALATED CALLS REPORT
// ═══════════════════════════════════════════════════
router.get('/escalated', (req, res, next) => {
  try {
    const db = getDb();

    let query = `
      SELECT esc.*, 
             cr.ticket_no, 
             c.name AS customer_name, 
             c.mobile, 
             ef.name AS from_name, 
             et.name AS to_name, 
             cr.issue_description 
      FROM escalations esc 
      LEFT JOIN call_records cr ON esc.call_record_id = cr.id 
      LEFT JOIN customers c ON cr.customer_id = c.id 
      LEFT JOIN employees ef ON esc.escalated_from = ef.id 
      LEFT JOIN employees et ON esc.escalated_to = et.id 
    `;
    const params = [];

    if (req.session.user && req.session.user.role !== 'admin') {
      const emp = db.prepare('SELECT id FROM employees WHERE user_id = ?').get(req.session.user.id);
      const empId = emp ? emp.id : -1;
      query += ` WHERE (esc.escalated_from = ? OR esc.escalated_to = ?)`;
      params.push(empId, empId);
    }

    query += ` ORDER BY esc.escalated_at DESC`;

    const escalations = db.prepare(query).all(...params);

    res.render('reports/escalated', {
      escalations
    });
  } catch (err) {
    next(err);
  }
});

// ═══════════════════════════════════════════════════
//  6. EMPLOYEE-WISE CALL SUMMARY (Admin Only)
// ═══════════════════════════════════════════════════
router.get('/employee-wise', isAdmin, (req, res, next) => {
  try {
    const db = getDb();
    const today = new Date();
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(today.getDate() - 30);

    const fromDate = req.query.from_date || thirtyDaysAgo.toISOString().slice(0, 10);
    const toDate = req.query.to_date || today.toISOString().slice(0, 10);

    const summary = db.prepare(`
      SELECT e.id,
             e.name, 
             e.emp_code, 
             e.designation,
             COUNT(cr.id) AS total, 
             SUM(CASE WHEN cr.status = 'resolved' THEN 1 ELSE 0 END) AS resolved, 
             SUM(CASE WHEN cr.status IN ('open', 'assigned', 'in_progress') THEN 1 ELSE 0 END) AS pending, 
             SUM(CASE WHEN cr.status = 'escalated' THEN 1 ELSE 0 END) AS escalated, 
             ROUND(AVG(CASE WHEN cr.duration > 0 THEN cr.duration ELSE NULL END), 1) AS avg_duration 
      FROM employees e 
      LEFT JOIN call_records cr ON e.id = cr.employee_id 
           AND date(cr.call_date) BETWEEN date(?) AND date(?)
      WHERE e.is_active = 1
      GROUP BY e.id, e.name, e.emp_code, e.designation
      ORDER BY total DESC, e.name ASC
    `).all(fromDate, toDate);

    res.render('reports/employee-wise', {
      summary,
      fromDate,
      toDate
    });
  } catch (err) {
    next(err);
  }
});

// ═══════════════════════════════════════════════════
//  7. AUDIT LOG REPORT (Admin Only)
// ═══════════════════════════════════════════════════
router.get('/audit-log', isAdmin, (req, res, next) => {
  try {
    const db = getDb();
    const fromDate = req.query.from_date || '';
    const toDate = req.query.to_date || '';
    const actionFilter = req.query.action || '';

    let query = `
      SELECT al.*, u.username, u.role
      FROM activity_log al
      LEFT JOIN users u ON al.user_id = u.id
      WHERE 1=1
    `;
    const params = [];

    if (fromDate) {
      query += ` AND date(al.created_at) >= date(?)`;
      params.push(fromDate);
    }
    if (toDate) {
      query += ` AND date(al.created_at) <= date(?)`;
      params.push(toDate);
    }
    if (actionFilter) {
      query += ` AND al.action LIKE ?`;
      params.push(`%${actionFilter}%`);
    }

    query += ` ORDER BY al.created_at DESC LIMIT 500`;

    const logs = db.prepare(query).all(...params);

    res.render('reports/audit-log', {
      logs,
      fromDate,
      toDate,
      actionFilter
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
