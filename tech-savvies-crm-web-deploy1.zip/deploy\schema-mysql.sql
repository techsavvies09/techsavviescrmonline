-- =======================================================
-- Tech Savvies ERP Support Call CRM
-- Relational Database Schema (MySQL 5.7+ / 8.0+)
-- =======================================================

SET FOREIGN_KEY_CHECKS = 0;

-- 1. Users Table
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(100) UNIQUE NOT NULL,
  `email` VARCHAR(191) UNIQUE NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('admin', 'user', 'employee') NOT NULL DEFAULT 'user',
  `status` ENUM('pending', 'approved', 'rejected', 'blocked') NOT NULL DEFAULT 'pending',
  `reset_token` VARCHAR(255) NULL,
  `reset_token_expires` DATETIME NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Plan Versions Master Table
CREATE TABLE IF NOT EXISTS `plan_versions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `plan_code` VARCHAR(50) UNIQUE NOT NULL,
  `plan_name` VARCHAR(150) NOT NULL,
  `description` TEXT NULL,
  `version_no` VARCHAR(50) NULL,
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Employees Master Table
CREATE TABLE IF NOT EXISTS `employees` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNIQUE NULL,
  `emp_code` VARCHAR(50) UNIQUE NOT NULL,
  `name` VARCHAR(150) NOT NULL,
  `email` VARCHAR(191) NOT NULL,
  `phone` VARCHAR(50) NULL,
  `designation` VARCHAR(100) NULL,
  `department` VARCHAR(100) NULL,
  `address` TEXT NULL,
  `profile_pic` VARCHAR(255) NULL,
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `fk_emp_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Customers Master Table
CREATE TABLE IF NOT EXISTS `customers` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `customer_code` VARCHAR(50) UNIQUE NOT NULL,
  `name` VARCHAR(150) NOT NULL,
  `company` VARCHAR(150) NULL,
  `email` VARCHAR(191) NULL,
  `mobile` VARCHAR(50) NOT NULL,
  `phone` VARCHAR(50) NULL,
  `plan_version` VARCHAR(150) NULL,
  `address` TEXT NULL,
  `city` VARCHAR(100) NULL,
  `state` VARCHAR(100) NULL,
  `pincode` VARCHAR(20) NULL,
  `gst_no` VARCHAR(50) NULL,
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Issues Master Table
CREATE TABLE IF NOT EXISTS `issues_master` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `issue_code` VARCHAR(50) UNIQUE NOT NULL,
  `category` VARCHAR(100) NOT NULL,
  `sub_category` VARCHAR(100) NULL,
  `description` TEXT NOT NULL,
  `priority` ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
  `estimated_time` INT DEFAULT 30,
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Call Records Table
CREATE TABLE IF NOT EXISTS `call_records` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `ticket_no` VARCHAR(50) UNIQUE NOT NULL,
  `customer_id` INT NOT NULL,
  `employee_id` INT NULL,
  `call_date` DATE NOT NULL,
  `call_time` TIME NOT NULL,
  `duration` INT DEFAULT 0,
  `plan_version` VARCHAR(150) NULL,
  `issue_id` INT NULL,
  `issue_description` TEXT NULL,
  `status` ENUM('open', 'assigned', 'in_progress', 'resolved', 'escalated', 'closed') DEFAULT 'open',
  `resolution_notes` TEXT NULL,
  `resolved_at` DATETIME NULL,
  `resolved_by` INT NULL,
  `created_by` INT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `fk_call_cust` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `fk_call_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_call_issue` FOREIGN KEY (`issue_id`) REFERENCES `issues_master` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_call_resolved_by` FOREIGN KEY (`resolved_by`) REFERENCES `employees` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_call_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. Call Allocations Table
CREATE TABLE IF NOT EXISTS `call_allocations` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `call_record_id` INT NOT NULL,
  `allocated_to` INT NOT NULL,
  `allocated_by` INT NOT NULL,
  `allocated_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `status` ENUM('assigned', 'accepted', 'in_progress', 'completed', 'reassigned') DEFAULT 'assigned',
  `notes` TEXT NULL,
  CONSTRAINT `fk_alloc_call` FOREIGN KEY (`call_record_id`) REFERENCES `call_records` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_alloc_to` FOREIGN KEY (`allocated_to`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_alloc_by` FOREIGN KEY (`allocated_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. Escalations Table
CREATE TABLE IF NOT EXISTS `escalations` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `call_record_id` INT NOT NULL,
  `escalated_from` INT NULL,
  `escalated_to` INT NULL,
  `reason` TEXT NOT NULL,
  `priority` ENUM('medium', 'high', 'critical') DEFAULT 'high',
  `status` ENUM('pending', 'assigned', 'resolved') DEFAULT 'pending',
  `resolution_notes` TEXT NULL,
  `escalated_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `resolved_at` DATETIME NULL,
  CONSTRAINT `fk_esc_call` FOREIGN KEY (`call_record_id`) REFERENCES `call_records` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_esc_from` FOREIGN KEY (`escalated_from`) REFERENCES `employees` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_esc_to` FOREIGN KEY (`escalated_to`) REFERENCES `employees` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. Notifications Table
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `call_record_id` INT NULL,
  `customer_id` INT NULL,
  `type` ENUM('sms', 'email') NOT NULL,
  `recipient` VARCHAR(191) NOT NULL,
  `subject` VARCHAR(255) NULL,
  `message` TEXT NOT NULL,
  `status` ENUM('pending', 'sent', 'failed') DEFAULT 'pending',
  `sent_at` DATETIME NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_notif_call` FOREIGN KEY (`call_record_id`) REFERENCES `call_records` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_notif_cust` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. Activity Log Table
CREATE TABLE IF NOT EXISTS `activity_log` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NULL,
  `action` VARCHAR(100) NOT NULL,
  `details` TEXT NULL,
  `ip_address` VARCHAR(45) NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_audit_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11. Change Requests Table
CREATE TABLE IF NOT EXISTS `change_requests` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `request_type` ENUM('username', 'password', 'both') NOT NULL,
  `requested_username` VARCHAR(100) NULL,
  `requested_password` VARCHAR(255) NULL,
  `reason` TEXT NULL,
  `status` ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
  `admin_notes` TEXT NULL,
  `reviewed_by` INT NULL,
  `reviewed_at` DATETIME NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_cr_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cr_reviewer` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
