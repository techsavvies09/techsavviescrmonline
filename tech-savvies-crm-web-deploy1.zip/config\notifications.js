// Tech Savvies ERP Support Call CRM - Email/SMS Notification Service
const nodemailer = require('nodemailer');

// Create email transporter
function createTransporter() {
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST || 'smtp.gmail.com',
    port: parseInt(process.env.SMTP_PORT) || 587,
    secure: false,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS
    },
    tls: { rejectUnauthorized: false }
  });
}

// Send email notification
async function sendEmail(to, subject, htmlBody) {
  try {
    const transporter = createTransporter();
    const info = await transporter.sendMail({
      from: `"Tech Savvies Support" <${process.env.SMTP_FROM || process.env.SMTP_USER}>`,
      to: to,
      subject: subject,
      html: htmlBody
    });
    console.log('📧 Email sent:', info.messageId);
    return { success: true, messageId: info.messageId };
  } catch (error) {
    console.error('❌ Email send error:', error.message);
    return { success: false, error: error.message };
  }
}

// Send resolution notification to customer
async function sendResolutionNotification(customer, ticketNo, issueDescription, resolutionNotes) {
  const subject = `Issue Resolved - Ticket #${ticketNo} | Tech Savvies Support`;
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <div style="background: linear-gradient(135deg, #1a237e, #c62828); padding: 20px; text-align: center;">
        <h1 style="color: #fff; margin: 0;">Tech Savvies</h1>
        <p style="color: #ddd; margin: 5px 0 0;">Business Software Solution Provider</p>
      </div>
      <div style="padding: 30px; background: #f9f9f9;">
        <h2 style="color: #1a237e;">Issue Resolved ✅</h2>
        <p>Dear <strong>${customer.name}</strong>,</p>
        <p>We are pleased to inform you that your support ticket has been resolved.</p>
        <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
          <tr style="background: #e3f2fd;">
            <td style="padding: 10px; border: 1px solid #ddd; font-weight: bold;">Ticket No</td>
            <td style="padding: 10px; border: 1px solid #ddd;">${ticketNo}</td>
          </tr>
          <tr>
            <td style="padding: 10px; border: 1px solid #ddd; font-weight: bold;">Issue</td>
            <td style="padding: 10px; border: 1px solid #ddd;">${issueDescription}</td>
          </tr>
          <tr style="background: #e8f5e9;">
            <td style="padding: 10px; border: 1px solid #ddd; font-weight: bold;">Resolution</td>
            <td style="padding: 10px; border: 1px solid #ddd;">${resolutionNotes}</td>
          </tr>
        </table>
        <p>If you face any further issues, please don't hesitate to contact our support team.</p>
        <p style="margin-top: 30px;">Best Regards,<br><strong>Tech Savvies Support Team</strong><br>
        📞 Support Helpline | ✉️ support@techsavvies.com</p>
      </div>
      <div style="background: #333; color: #aaa; padding: 15px; text-align: center; font-size: 12px;">
        © ${new Date().getFullYear()} Tech Savvies - Business Software Solution Provider
      </div>
    </div>
  `;
  
  if (customer.email) {
    return await sendEmail(customer.email, subject, html);
  }
  return { success: false, error: 'No customer email address' };
}

// Send SMS notification (placeholder - integrate with SMS gateway)
async function sendSMS(mobile, message) {
  // TODO: Integrate with SMS gateway (Twilio, MSG91, etc.)
  console.log(`📱 SMS to ${mobile}: ${message}`);
  return { success: true, note: 'SMS gateway not configured. Message logged.' };
}

// Send escalation notification
async function sendEscalationNotification(employee, ticketNo, reason) {
  const subject = `Escalation Alert - Ticket #${ticketNo} | Tech Savvies`;
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <div style="background: linear-gradient(135deg, #e65100, #c62828); padding: 20px; text-align: center;">
        <h1 style="color: #fff; margin: 0;">⚠️ Escalation Alert</h1>
      </div>
      <div style="padding: 30px; background: #fff3e0;">
        <p>Dear <strong>${employee.name}</strong>,</p>
        <p>A support ticket has been escalated to you.</p>
        <p><strong>Ticket:</strong> ${ticketNo}</p>
        <p><strong>Reason:</strong> ${reason}</p>
        <p>Please attend to this issue on priority.</p>
      </div>
    </div>
  `;
  
  if (employee.email) {
    return await sendEmail(employee.email, subject, html);
  }
  return { success: false, error: 'No employee email' };
}

// Send complaint registration confirmation to customer
async function sendComplaintRegistrationNotification(customer, ticketNo, issueCategory, issueDescription) {
  const subject = `Complaint Registered - Ticket #${ticketNo} | Tech Savvies Support`;
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; border: 1px solid #e0e0e0; border-radius: 8px; overflow: hidden;">
      <div style="background: linear-gradient(135deg, #1a237e, #c62828); padding: 25px; text-align: center;">
        <h1 style="color: #fff; margin: 0; font-size: 24px;">Tech Savvies</h1>
        <p style="color: #ffebee; margin: 5px 0 0; font-size: 13px;">Business Software Solution Provider</p>
      </div>
      <div style="padding: 30px; background: #ffffff;">
        <h2 style="color: #1a237e; margin-top: 0;">Support Complaint Registered 📋</h2>
        <p>Dear <strong>${customer.name || 'Valued Customer'}</strong>,</p>
        <p>Thank you for reaching out. Your support complaint has been successfully recorded in our system and assigned to our technical support desk.</p>
        
        <div style="background: #e8eaf6; padding: 15px; border-left: 4px solid #1a237e; border-radius: 4px; margin: 20px 0;">
          <p style="margin: 0; font-size: 13px; color: #555;">Your Support Ticket Number:</p>
          <h2 style="margin: 5px 0 0; color: #1a237e; font-size: 22px; letter-spacing: 1px;">${ticketNo}</h2>
        </div>

        <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
          <tr style="border-bottom: 1px solid #eee;">
            <td style="padding: 10px 0; color: #777; width: 35%;">Category:</td>
            <td style="padding: 10px 0; font-weight: 600; color: #333;">${issueCategory || 'ERP Support'}</td>
          </tr>
          <tr style="border-bottom: 1px solid #eee;">
            <td style="padding: 10px 0; color: #777;">Issue Description:</td>
            <td style="padding: 10px 0; color: #333;">${issueDescription || 'Not specified'}</td>
          </tr>
          <tr style="border-bottom: 1px solid #eee;">
            <td style="padding: 10px 0; color: #777;">Status:</td>
            <td style="padding: 10px 0;"><span style="background: #fff3e0; color: #e65100; padding: 4px 10px; border-radius: 12px; font-size: 12px; font-weight: bold;">Open / In Queue</span></td>
          </tr>
        </table>

        <p style="color: #555; font-size: 14px; line-height: 1.5;">
          Our ERP support engineer will attend to your request shortly. You can track this ticket anytime using your Ticket Number or Mobile Number.
        </p>

        <p style="margin-top: 30px; font-size: 14px; color: #333;">
          Warm Regards,<br>
          <strong>Tech Savvies Support Team</strong><br>
          📞 Support Helpline | ✉️ support@techsavvies.com
        </p>
      </div>
      <div style="background: #263238; color: #b0bec5; padding: 15px; text-align: center; font-size: 12px;">
        © ${new Date().getFullYear()} Tech Savvies - Business Software Solution Provider
      </div>
    </div>
  `;
  
  if (customer.email) {
    return await sendEmail(customer.email, subject, html);
  }
  return { success: false, error: 'No customer email address' };
}

module.exports = { sendEmail, sendResolutionNotification, sendComplaintRegistrationNotification, sendSMS, sendEscalationNotification };
